// src/components/AccountingPanel.jsx
import React, { useState, useMemo, useEffect, useRef } from 'react';
import html2canvas from 'html2canvas';
import useImages from '../hooks/useImages';
import {
  Button, TextInput, Select, Modal, ActionIcon, Badge, Card, Text,
  Textarea, SegmentedControl, Tooltip, Divider, Alert, NumberInput,
} from '@mantine/core';
import { notifications } from '@mantine/notifications';
import {
  IconPlus, IconTrash, IconEdit, IconPhoto, IconX,
  IconCash, IconReportMoney, IconReceipt, IconCalendar, IconUser,
  IconTruckDelivery, IconPackage, IconBox, IconChartBar,
  IconUsers, IconClock, IconCheck, IconAlertTriangle,
  IconBell, IconBellRinging, IconArrowRight, IconCategory,
  IconDiamond, IconWallet, IconPigMoney, IconHandGrab,
  IconCircleCheck, IconFileInvoice, IconCoins, IconScale,
  IconUserCircle, IconBriefcase, IconPercentage, IconArrowsSplit,
  IconMoneybag, IconInfoCircle, IconListDetails, IconChartDots,
  IconBuildingFactory, IconTool, IconAddressBook, IconPhone,
  IconDownload, IconShare2, IconArrowUpRight, IconShield,
} from '@tabler/icons-react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  addSale, updateSale, deleteSale, getSales,
  addInvestment, updateInvestment, deleteInvestment, getInvestments,
  getShareholders,
  addPendingSale, updatePendingSale, deletePendingSale, getPendingSales, completePendingSale,
  addCapital, updateCapital, deleteCapital, getCapital,
  addFrecuentClient, deleteFrecuentClient, getFrecuentClients,
  getPagosAccionista, addPagoAccionista, deletePagoAccionista,
  generateId, imageToBase64, loadStore,
} from '../utils/store';
import { COLORS } from '../utils/theme';
import StatsPanel from './StatsPanel';
import { deductInventory, getProductInventory, getSizeStock, checkAndSyncSoldOut } from '../utils/inventory';

const SOCIOS_OPTIONS = [
  { value: 'Yefer', label: 'Yefer' },
  { value: 'Frank', label: 'Frank' },
  { value: 'Ambos', label: 'Ambos socios' },
];
const MEDIOS_ENTREGA = ['Contra entrega', 'Shalom', 'Envio delivery', 'Recojo en tienda'];
const CATEGORIAS_INVERSION = [
  'Insumos', 'Cajas', 'Reabastecer stock', 'Empaques',
  'Publicidad', 'Herramientas', 'Envios', 'Otros',
];
const FUENTE_DINERO_OPTIONS = [
  { value: 'Yefer', label: 'Yefer' },
  { value: 'Frank', label: 'Frank' },
  { value: 'Ambos', label: 'Ambos socios' },
  { value: 'Accionista', label: 'Dinero de accionista' },
];

/* ====== ESTILOS del SegmentedControl (fix texto negro) ====== */
const SEGMENT_STYLES = {
  root: { background: COLORS.borderLight, border: 'none' },
  indicator: { background: COLORS.navy, borderRadius: 20 },
  label: {
    fontFamily: '"Outfit", sans-serif',
    fontSize: '0.68rem',
    fontWeight: 500,
    color: COLORS.navy,
    padding: '6px 4px',
  },
  innerLabel: { color: 'inherit' },
};

/* ====== UTILIDADES ====== */
function localToday() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/**
 * Parsea un string "YYYY-MM-DD" como hora LOCAL (no UTC).
 * Sin esto, new Date("2025-06-14") = medianoche UTC = 19:00 Perú del día 13
 * → siempre muestra un día menos.
 */
function parseDateLocal(dateStr) {
  if (!dateStr) return new Date(NaN);
  // Si ya tiene hora incluida (ISO completo) parsear normalmente
  if (dateStr.includes('T') || dateStr.includes(' ')) return new Date(dateStr);
  // Fecha pura YYYY-MM-DD → forzar hora local 00:00:00
  return new Date(dateStr + 'T00:00:00');
}

/**
 * Formatea un string de fecha a dd/mm/aaaa sin desfase de zona horaria.
 */
function formatDateLocal(dateStr, options = { day: '2-digit', month: '2-digit', year: 'numeric' }) {
  if (!dateStr) return '';
  return parseDateLocal(dateStr).toLocaleDateString('es-PE', options);
}
function getDaysUntil(dateStr) {
  if (!dateStr) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(dateStr + 'T00:00:00');
  return Math.ceil((target - today) / (1000 * 60 * 60 * 24));
}
function getUrgencyColor(days) {
  if (days === null) return 'gray';
  if (days < 0) return 'red';
  if (days === 0) return 'orange';
  if (days <= 2) return 'yellow';
  return 'blue';
}
function getUrgencyText(days) {
  if (days === null) return 'Sin fecha';
  if (days < 0) return `Vencida hace ${Math.abs(days)} dia(s)`;
  if (days === 0) return 'HOY';
  if (days === 1) return 'Manana';
  return `En ${days} dias`;
}

/* ====== Calcular la parte real que le toca a un socio en una venta ====== */
function getSocioAmount(item, socioName) {
  const total = parseFloat(item.precio || item.monto) || 0;
  if (item.socio === socioName) return total;
  if (item.socio === 'Ambos') {
    if (socioName === 'Yefer') return parseFloat(item.splitYefer) || 0;
    if (socioName === 'Frank') return parseFloat(item.splitFrank) || 0;
  }
  return 0;
}

/* ====== Notificaciones del navegador (gratuito) ====== */
function requestNotificationPermission() {
  if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
  }
}
function sendBrowserNotification(title, body) {
  if ('Notification' in window && Notification.permission === 'granted') {
    new Notification(title, { body, icon: '/logo.png', tag: 'benito-reminder' });
  }
}

/* ================================================================
   COMPONENTE PRINCIPAL
   ================================================================ */
export default function AccountingPanel({ storeData, onRefresh }) {
  const [subTab, setSubTab] = useState('ventas');
  const [saleModal, setSaleModal] = useState({ open: false, sale: null });
  const [investModal, setInvestModal] = useState({ open: false, investment: null });
  const [pendingModal, setPendingModal] = useState({ open: false, pending: null });
  const [filterSocio, setFilterSocio] = useState('todos');

  // Mes actual como default
  const summaryRef = useRef(null);

  const currentMonthKey = useMemo(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  }, []);
  const [filterMonth, setFilterMonth] = useState('general');

  const sales = useMemo(() => getSales(), [storeData]);
  const investments = useMemo(() => getInvestments(), [storeData]);
  const shareholders = useMemo(() => getShareholders(), [storeData]);
  const pendingSales = useMemo(() => getPendingSales(), [storeData]);
  const capital = useMemo(() => getCapital(), [storeData]);
  const frecuentClients = useMemo(() => getFrecuentClients(), [storeData]);
  const pagosAccionista = useMemo(() => getPagosAccionista(), [storeData]);
  const allCategories = useMemo(() => (storeData?.categories || []).sort((a, b) => a.order - b.order), [storeData]);
  const allProducts = useMemo(() => storeData?.products || [], [storeData]);

  useEffect(() => { requestNotificationPermission(); }, []);

  useEffect(() => {
    const active = pendingSales.filter(p => !p.completed);
    const dueToday = active.filter(p => getDaysUntil(p.fechaEntrega) === 0);
    const overdue = active.filter(p => getDaysUntil(p.fechaEntrega) < 0);
    if (dueToday.length > 0) sendBrowserNotification('Ventas para HOY', `Tienes ${dueToday.length} venta(s) pendiente(s) para hoy`);
    if (overdue.length > 0) sendBrowserNotification('Ventas VENCIDAS', `Tienes ${overdue.length} venta(s) vencida(s) sin completar`);
  }, [pendingSales]);

  // Helper: filtrar por mes
  const filterByMonth = (items, dateField = 'fecha') => {
    if (filterMonth === 'general') return items;
    return items.filter(item => {
      if (!item[dateField]) return false;
      const d = parseDateLocal(item[dateField]);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}` === filterMonth;
    });
  };

  // Ventas filtradas (por mes + socio)
  const filteredSales = useMemo(() => {
    let filtered = filterByMonth(sales);
    if (filterSocio !== 'todos') {
      filtered = filtered.filter(s => s.socio === filterSocio || s.socio === 'Ambos');
    }
    return filtered.sort((a, b) => parseDateLocal(b.fecha) - parseDateLocal(a.fecha));
  }, [sales, filterSocio, filterMonth]);

  // Inversiones filtradas por mes
  const filteredInvestments = useMemo(() => filterByMonth(investments), [investments, filterMonth]);

  // Totales del mes (o general)
  const totalVentas = filteredSales.reduce((sum, s) => sum + (parseFloat(s.precio) || 0), 0);
  // Capital = herramientas/equipos que generan dinero → NO restan ganancia
  const totalCapital = filteredInvestments.filter(i => i.esCapital).reduce((sum, i) => sum + (parseFloat(i.monto) || 0), 0);
  // Gastos operativos = lo que sí resta ganancia (insumos, cajas, publicidad, etc.)
  const totalGastosOperativos = filteredInvestments.filter(i => !i.esCapital).reduce((sum, i) => sum + (parseFloat(i.monto) || 0), 0);
  const totalInversiones = totalGastosOperativos; // alias para compatibilidad
  const totalCostosVentas = filteredSales.reduce((sum, s) => sum + (parseFloat(s.costosAgregados) || 0), 0);
  const ganancia = totalVentas - totalGastosOperativos - totalCostosVentas;

  // Totales por socio (con splits) - del mes
  const ventasPorSocio = useMemo(() => {
    const map = {};
    ['Yefer', 'Frank'].forEach(s => { map[s] = { totalVentas: 0, countVentas: 0, totalInversion: 0, countInversion: 0 }; });
    filteredSales.forEach(s => {
      ['Yefer', 'Frank'].forEach(socio => {
        const amt = getSocioAmount(s, socio);
        if (amt > 0) { map[socio].totalVentas += amt; map[socio].countVentas += 1; }
      });
    });
    filteredInvestments.filter(inv => !inv.esCapital).forEach(inv => {
      ['Yefer', 'Frank'].forEach(socio => {
        const amt = getSocioAmount({ ...inv, precio: inv.monto, socio: inv.fuenteDinero || inv.socio }, socio);
        if (amt > 0) { map[socio].totalInversion += amt; map[socio].countInversion += 1; }
      });
    });
    return map;
  }, [filteredSales, filteredInvestments]);

  // Meses disponibles (de ventas + inversiones)
  const availableMonths = useMemo(() => {
    const months = new Set();
    sales.forEach(s => { if (s.fecha) { const d = parseDateLocal(s.fecha); months.add(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`); } });
    investments.forEach(i => { if (i.fecha) { const d = parseDateLocal(i.fecha); months.add(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`); } });
    const names = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    return Array.from(months).sort().reverse().map(m => {
      const [y, mo] = m.split('-');
      return { value: m, label: `${names[parseInt(mo) - 1]} ${y}` };
    });
  }, [sales, investments]);

  // Mes actual label
  const currentMonthLabel = useMemo(() => {
    if (filterMonth === 'general') return 'General (todo)';
    const found = availableMonths.find(m => m.value === filterMonth);
    return found ? found.label : filterMonth;
  }, [filterMonth, availableMonths]);

  const handleExportSummary = async () => {
    if (!summaryRef.current) return;
    try {
      const canvas = await html2canvas(summaryRef.current, {
        scale: 2, useCORS: true, backgroundColor: '#ffffff',
        logging: false,
      });
      const link = document.createElement('a');
      link.download = `resumen-${currentMonthLabel.replace(/ /g, '-')}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (e) {
      console.error('Export error:', e);
    }
  };

  const activePending = pendingSales.filter(p => !p.completed);
  const overduePending = activePending.filter(p => getDaysUntil(p.fechaEntrega) < 0);
  const todayPending = activePending.filter(p => getDaysUntil(p.fechaEntrega) === 0);

  // Fondo accionista: total aportado - usado (inversiones + costos de ventas pagados con dinero del accionista)
  const totalAccionistas = shareholders.reduce((sum, sh) => sum + (parseFloat(sh.monto) || 0), 0);
  const invFromAccionista = investments.filter(i => i.fuenteDinero === 'Accionista').reduce((sum, i) => sum + (parseFloat(i.monto) || 0), 0);
  const costosFromAccionista = sales.filter(s => s.fuenteCostos === 'Accionista').reduce((sum, s) => sum + (parseFloat(s.costosAgregados) || 0), 0);
  const totalUsadoAccionista = invFromAccionista + costosFromAccionista;
  const fondoDisponible = totalAccionistas - totalUsadoAccionista;

  return (
    <div>
      {/* ALERTAS */}
      {overduePending.length > 0 && (
        <Alert icon={<IconAlertTriangle size={18} />} color="red" variant="light" radius="md" mb={8}
          title={`${overduePending.length} venta(s) VENCIDA(S)`}
          styles={{ title: { fontFamily: '"Outfit", sans-serif', fontWeight: 600 } }}>
          <div style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.75rem' }}>
            {overduePending.map(p => (
              <div key={p.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '2px 0' }}>
                <span>{p.cliente} - {p.producto}</span>
                <Badge size="xs" color="red" variant="filled" radius="xl">{getUrgencyText(getDaysUntil(p.fechaEntrega))}</Badge>
              </div>
            ))}
          </div>
        </Alert>
      )}
      {todayPending.length > 0 && (
        <Alert icon={<IconBellRinging size={18} />} color="orange" variant="light" radius="md" mb={8}
          title={`${todayPending.length} venta(s) para HOY`}
          styles={{ title: { fontFamily: '"Outfit", sans-serif', fontWeight: 600 } }}>
          <div style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.75rem' }}>
            {todayPending.map(p => (
              <div key={p.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '2px 0' }}>
                <span>{p.cliente} - {p.producto}</span>
                <Badge size="xs" color="orange" variant="filled" radius="xl">HOY</Badge>
              </div>
            ))}
          </div>
        </Alert>
      )}

      {/* SELECTOR DE MES */}
      <Card padding="xs" radius="md" mb={8} style={{ background: COLORS.offWhite, border: `1px solid ${COLORS.borderLight}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <IconCalendar size={16} color={COLORS.navy} />
          <Text size="xs" fw={600} style={{ fontFamily: '"Outfit", sans-serif', color: COLORS.navy, flex: 1 }}>
            Periodo: {currentMonthLabel}
          </Text>
          <Select size="xs" value={filterMonth} placeholder="Mes"
            onChange={(v) => setFilterMonth(v || 'general')}
            data={[
              { value: 'general', label: 'General (todo)' },
              ...availableMonths,
            ]}
            radius="md" style={{ width: 140 }}
            styles={{ input: { fontSize: '0.7rem' } }} />
        </div>
      </Card>

      {/* RESUMEN FINANCIERO DEL MES */}
      <div ref={summaryRef} style={{ background: 'white', borderRadius: 14, padding: 2 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8, marginBottom: 8 }}>
        <SummaryCard icon={IconCash} label="Ventas" value={totalVentas} color="#2d8a2d" bg="#e6f9e6" border="#b8e6b8" />
        <SummaryCard icon={IconReportMoney} label="Gastos op." value={totalGastosOperativos + totalCostosVentas} color="#c92a2a" bg="#fee6e6" border="#e6b8b8" />
      </div>
      <div style={{ marginBottom: 8 }}>
        <SummaryCard icon={IconScale} label="Ganancia" value={ganancia}
          color={ganancia >= 0 ? '#2c4a80' : '#e8590c'}
          bg={ganancia >= 0 ? '#e6f0ff' : '#fff0e6'}
          border={ganancia >= 0 ? '#b8d4e6' : '#e6c8b8'} />
      </div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 8 }}>
        <button onClick={handleExportSummary}
          style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '5px 12px',
            background: COLORS.offWhite, border: `1px solid ${COLORS.borderLight}`,
            borderRadius: 20, cursor: 'pointer', fontFamily: '"Outfit", sans-serif',
            fontSize: '0.65rem', color: COLORS.navy, fontWeight: 500 }}>
          <IconDownload size={12} color={COLORS.navy} />
          Exportar resumen
        </button>
      </div>

      {/* Fondo accionista */}
      {totalAccionistas > 0 && (
        <Card padding="xs" radius="md" mb={8} style={{ background: '#f0f4ff', border: '1px solid #dde4f0' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 4 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <IconPigMoney size={16} color="#2c4a80" />
              <Text size="xs" style={{ fontFamily: '"Outfit", sans-serif', color: '#2c4a80' }}>
                Fondo accionista: <strong>S/.{totalAccionistas.toFixed(2)}</strong>
              </Text>
            </div>
            <Text size="xs" c="dimmed" style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.62rem' }}>
              Usado: S/.{totalUsadoAccionista.toFixed(2)} | Disponible: <strong style={{ color: fondoDisponible >= 0 ? '#2d8a2d' : '#c92a2a' }}>S/.{fondoDisponible.toFixed(2)}</strong>
            </Text>
          </div>
        </Card>
      )}

      {/* SUB-TABS - CORREGIDO: texto blanco en seleccionado */}
      <div style={{ marginBottom: 14 }}>
        <SegmentedControl value={subTab} onChange={setSubTab} fullWidth size="xs" radius="xl"
          data={[
            { value: 'ventas', label: 'Ventas' },
            { value: 'inversiones', label: 'Gastos' },
            { value: 'pendientes', label: 'Pendientes' },
            { value: 'socios', label: 'Socios' },
            { value: 'accionistas', label: 'Accionistas' },
            { value: 'stats', label: 'Estadisticas' },
          ]}
          styles={{
            root: { background: COLORS.borderLight, border: 'none' },
            indicator: { background: COLORS.navy, borderRadius: 20, boxShadow: '0 2px 8px rgba(26,39,68,0.25)' },
            label: {
              fontFamily: '"Outfit", sans-serif',
              fontSize: '0.62rem',
              fontWeight: 600,
              padding: '7px 4px',
              color: COLORS.navy,
              transition: 'color 0.2s ease',
            },
          }}
        />
      </div>

      {subTab === 'ventas' && (
        <VentasSection sales={filteredSales}
          filterSocio={filterSocio} setFilterSocio={setFilterSocio}
          onAdd={() => setSaleModal({ open: true, sale: null })}
          onEdit={(sale) => setSaleModal({ open: true, sale })}
          onDelete={(id) => { deleteSale(id); onRefresh(); notifications.show({ title: 'Eliminado', message: 'Venta eliminada', color: 'red' }); }}
        />
      )}
      {subTab === 'inversiones' && (
        <InversionesSection investments={filteredInvestments}
          onAdd={() => setInvestModal({ open: true, investment: null })}
          onEdit={(inv) => setInvestModal({ open: true, investment: inv })}
          onDelete={(id) => { deleteInvestment(id); onRefresh(); notifications.show({ title: 'Eliminado', message: 'Gasto eliminado', color: 'red' }); }}
        />
      )}
      {subTab === 'pendientes' && (
        <PendientesSection pendingSales={pendingSales}
          frecuentClients={frecuentClients} onRefresh={onRefresh}
          onAdd={() => setPendingModal({ open: true, pending: null })}
          onEdit={(p) => setPendingModal({ open: true, pending: p })}
          onDelete={(id) => { deletePendingSale(id); onRefresh(); notifications.show({ title: 'Eliminado', message: 'Pendiente eliminado', color: 'red' }); }}
          onComplete={(id) => { completePendingSale(id); onRefresh(); notifications.show({ title: 'Completada', message: 'Venta completada', color: 'green' }); }}
        />
      )}
      {subTab === 'socios' && <SociosSection ventasPorSocio={ventasPorSocio} sales={filteredSales} investments={filteredInvestments} />}
      {subTab === 'accionistas' && (
        <AccionistasSection sales={sales} investments={investments} capital={capital}
          pagosAccionista={pagosAccionista} onRefresh={onRefresh} />
      )}
      {subTab === 'stats' && <StatsPanel sales={sales} investments={investments} />}

      {/* MODALES */}
      <SaleFormModal open={saleModal.open} sale={saleModal.sale} categories={allCategories} products={allProducts}
        onClose={() => setSaleModal({ open: false, sale: null })}
        onSave={() => { onRefresh(); setSaleModal({ open: false, sale: null }); }} />
      <InvestmentFormModal open={investModal.open} investment={investModal.investment}
        totalAccionistas={totalAccionistas} totalUsadoAccionista={totalUsadoAccionista}
        onClose={() => setInvestModal({ open: false, investment: null })}
        onSave={() => { onRefresh(); setInvestModal({ open: false, investment: null }); }} />
      <PendingSaleFormModal open={pendingModal.open} pending={pendingModal.pending}
        categories={allCategories} products={allProducts}
        onClose={() => setPendingModal({ open: false, pending: null })}
        onSave={() => { onRefresh(); setPendingModal({ open: false, pending: null }); }} />
    </div>
  );
}

/* ====== SUMMARY CARD ====== */
function SummaryCard({ icon: Icon, label, value, color, bg, border, tooltip }) {
  const card = (
    <Card padding="xs" radius="md" style={{ background: bg, border: `1px solid ${border}`, textAlign: 'center', cursor: tooltip ? 'help' : 'default' }}>
      <Icon size={18} color={color} style={{ margin: '0 auto 2px' }} />
      <Text size="xs" c="dimmed" style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.62rem' }}>{label}</Text>
      <Text size="sm" fw={700} style={{ color, fontFamily: '"Outfit", sans-serif' }}>S/. {value.toFixed(2)}</Text>
    </Card>
  );
  if (tooltip) return <Tooltip label={tooltip} multiline w={200} withArrow position="bottom" styles={{ tooltip: { fontFamily: '"Outfit", sans-serif', fontSize: '0.65rem' } }}>{card}</Tooltip>;
  return card;
}

/* ====== SPLIT DISPLAY (muestra reparto entre socios) ====== */
function SplitBadges({ item }) {
  if (item.socio !== 'Ambos') return null;
  const sy = parseFloat(item.splitYefer) || 0;
  const sf = parseFloat(item.splitFrank) || 0;
  if (sy === 0 && sf === 0) return null;
  return (
    <div style={{ display: 'flex', gap: 3, marginTop: 2 }}>
      <Badge size="xs" variant="light" color="blue" radius="xl" style={{ fontSize: '0.55rem', textTransform: 'none' }}>
        Y: S/.{sy.toFixed(0)}
      </Badge>
      <Badge size="xs" variant="light" color="orange" radius="xl" style={{ fontSize: '0.55rem', textTransform: 'none' }}>
        F: S/.{sf.toFixed(0)}
      </Badge>
    </div>
  );
}

/* ====== EMPTY STATE ====== */
function EmptyState({ icon: Icon, text }) {
  return (
    <div style={{ textAlign: 'center', padding: '32px 16px' }}>
      <Icon size={32} color={COLORS.borderLight} style={{ margin: '0 auto 8px' }} />
      <Text size="xs" c="dimmed" style={{ fontFamily: '"Outfit", sans-serif' }}>{text}</Text>
    </div>
  );
}

/* ================================================================
   VENTAS SECTION
   ================================================================ */
function VentasSection({ sales, filterSocio, setFilterSocio, onAdd, onEdit, onDelete }) {
  return (
    <div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
        <Select size="xs" radius="xl" value={filterSocio}
          onChange={(v) => setFilterSocio(v || 'todos')}
          data={[{ value: 'todos', label: 'Todos' }, ...SOCIOS_OPTIONS]}
          style={{ flex: 1 }} clearable={false} leftSection={<IconUser size={14} />} />
      </div>
      <Button leftSection={<IconPlus size={14} />} onClick={onAdd}
        radius="xl" size="xs" style={{ background: COLORS.orange, marginBottom: 10, fontFamily: '"Outfit", sans-serif' }}>
        Registrar Venta
      </Button>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        <AnimatePresence>
          {sales.map((sale) => (
            <SaleListItem key={sale.id} sale={sale} onEdit={() => onEdit(sale)} onDelete={() => onDelete(sale.id)} />
          ))}
        </AnimatePresence>
        {sales.length === 0 && <EmptyState icon={IconReceipt} text="No hay ventas registradas" />}
      </div>
    </div>
  );
}

function SaleListItem({ sale, onEdit, onDelete }) {
  const fechaStr = formatDateLocal(sale.fecha);
  const socioColor = sale.socio === 'Yefer' ? 'blue' : sale.socio === 'Frank' ? 'orange' : sale.socio === 'Ambos' ? 'grape' : 'gray';
  return (
    <motion.div layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -80 }}>
      <Card padding="xs" radius="md" style={{ border: `1px solid ${COLORS.borderLight}`, background: COLORS.white }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          {sale.foto ? (
            <div style={{ width: 42, height: 42, borderRadius: 8, overflow: 'hidden', flexShrink: 0 }}>
              <img src={sale.foto} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            </div>
          ) : (
            <div style={{ width: 42, height: 42, borderRadius: 8, background: COLORS.offWhite, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <IconReceipt size={16} color={COLORS.borderLight} />
            </div>
          )}
          <div style={{ flex: 1, minWidth: 0 }}>
            <Text size="xs" fw={600} lineClamp={1} style={{ fontFamily: '"Outfit", sans-serif' }}>{sale.producto || 'Sin nombre'}</Text>
            <div style={{ display: 'flex', gap: 4, alignItems: 'center', flexWrap: 'wrap' }}>
              <Text size="xs" c="dimmed" style={{ fontSize: '0.62rem' }}>{fechaStr}</Text>
              {sale.socio && <Badge size="xs" variant="light" color={socioColor} radius="xl" style={{ fontSize: '0.56rem' }}>{sale.socio}</Badge>}
              {sale.medioEntrega && <Badge size="xs" variant="outline" color="gray" radius="xl" style={{ fontSize: '0.56rem' }}>{sale.medioEntrega}</Badge>}
            </div>
            <SplitBadges item={sale} />
            {(sale.costosAgregados || sale.rebaja === 'si') && (
              <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginTop: 2 }}>
                {sale.costosAgregados && parseFloat(sale.costosAgregados) > 0 && (
                  <Badge size="xs" variant="light" color="red" radius="xl" style={{ fontSize: '0.52rem', textTransform: 'none' }}>
                    Costo: -S/.{sale.costosAgregados}{sale.fuenteCostos ? ` (${sale.fuenteCostos})` : ''}{sale.detalleCostos ? ` - ${sale.detalleCostos}` : ''}
                  </Badge>
                )}
                {sale.rebaja === 'si' && sale.montoRebaja && (
                  <Badge size="xs" variant="light" color="teal" radius="xl" style={{ fontSize: '0.52rem', textTransform: 'none' }}>
                    Rebaja: -S/.{sale.montoRebaja}
                  </Badge>
                )}
              </div>
            )}
          </div>
          <Text size="xs" fw={700} style={{ color: '#2d8a2d', fontFamily: '"Outfit", sans-serif', flexShrink: 0 }}>S/.{sale.precio || '0'}</Text>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <ActionIcon variant="light" color="blue" radius="xl" size="xs" onClick={onEdit}><IconEdit size={11} /></ActionIcon>
            <ActionIcon variant="light" color="red" radius="xl" size="xs" onClick={onDelete}><IconTrash size={11} /></ActionIcon>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}

/* ================================================================
   INVERSIONES / GASTOS SECTION
   ================================================================ */
function InversionesSection({ investments, onAdd, onEdit, onDelete }) {
  const gastosOp = investments.filter(i => !i.esCapital);
  const capitalItems = investments.filter(i => i.esCapital);

  const totalPorCategoria = useMemo(() => {
    const map = {};
    gastosOp.forEach(inv => { const c = inv.categoria || 'Otros'; map[c] = (map[c] || 0) + (parseFloat(inv.monto) || 0); });
    return map;
  }, [gastosOp]);
  const sortedGastos = [...gastosOp].sort((a, b) => parseDateLocal(b.fecha) - parseDateLocal(a.fecha));
  const sortedCapital = [...capitalItems].sort((a, b) => parseDateLocal(b.fecha) - parseDateLocal(a.fecha));
  const totalCapitalVal = capitalItems.reduce((s, i) => s + (parseFloat(i.monto) || 0), 0);

  return (
    <div>
      {/* Resumen por categoría */}
      {Object.keys(totalPorCategoria).length > 0 && (
        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 10 }}>
          {Object.entries(totalPorCategoria).map(([cat, total]) => (
            <Badge key={cat} size="sm" radius="xl" variant="light" color="red" style={{ fontFamily: '"Outfit", sans-serif', textTransform: 'none', fontSize: '0.6rem' }}>
              {cat}: S/.{total.toFixed(2)}
            </Badge>
          ))}
        </div>
      )}

      <Button leftSection={<IconPlus size={14} />} onClick={onAdd}
        radius="xl" size="xs" style={{ background: '#c92a2a', marginBottom: 12, fontFamily: '"Outfit", sans-serif' }}>
        Registrar Gasto
      </Button>

      {/* GASTOS OPERATIVOS */}
      <div style={{ marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
          <IconReportMoney size={14} color="#c92a2a" />
          <Text size="xs" fw={700} style={{ fontFamily: '"Outfit", sans-serif', color: '#c92a2a', fontSize: '0.72rem' }}>
            Gastos operativos
          </Text>
          <Text size="xs" c="dimmed" style={{ fontSize: '0.6rem', marginLeft: 'auto' }}>
            Restan ganancia
          </Text>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <AnimatePresence>
            {sortedGastos.map((inv) => (
              <InvestmentListItem key={inv.id} investment={inv} onEdit={() => onEdit(inv)} onDelete={() => onDelete(inv.id)} />
            ))}
          </AnimatePresence>
          {sortedGastos.length === 0 && <EmptyState icon={IconPackage} text="No hay gastos operativos" />}
        </div>
      </div>
    </div>
  );
}

function InvestmentListItem({ investment, onEdit, onDelete, isCapital }) {
  const fechaStr = formatDateLocal(investment.fecha);
  const iconMap = { 'Insumos': IconPackage, 'Cajas': IconBox, 'Reabastecer stock': IconPackage, 'Empaques': IconBox, 'Publicidad': IconChartBar, 'Envios': IconTruckDelivery, 'Herramientas': IconTool };
  const Ic = iconMap[investment.categoria] || (isCapital ? IconTool : IconReportMoney);
  const fuente = investment.fuenteDinero || investment.socio || '';
  const fuenteColor = fuente === 'Yefer' ? 'blue' : fuente === 'Frank' ? 'orange' : fuente === 'Ambos' ? 'grape' : fuente === 'Accionista' ? 'cyan' : 'gray';
  const cardBg = isCapital ? '#faf8ff' : COLORS.white;
  const iconBg = isCapital ? '#ede9ff' : '#fee6e6';
  const iconColor = isCapital ? '#7c3aed' : '#c92a2a';
  const amountColor = isCapital ? '#7c3aed' : '#c92a2a';

  return (
    <motion.div layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -80 }}>
      <Card padding="xs" radius="md" style={{ border: `1px solid ${isCapital ? '#d8c8f8' : COLORS.borderLight}`, background: cardBg }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <div style={{ width: 38, height: 38, borderRadius: 8, background: iconBg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Ic size={16} color={iconColor} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <Text size="xs" fw={600} lineClamp={1} style={{ fontFamily: '"Outfit", sans-serif' }}>{investment.descripcion || 'Sin descripcion'}</Text>
            <div style={{ display: 'flex', gap: 3, alignItems: 'center', flexWrap: 'wrap' }}>
              <Text size="xs" c="dimmed" style={{ fontSize: '0.62rem' }}>{fechaStr}</Text>
              {investment.categoria && <Badge size="xs" variant="light" color={isCapital ? 'violet' : 'red'} radius="xl" style={{ fontSize: '0.55rem' }}>{investment.categoria}</Badge>}
              {isCapital && <Badge size="xs" variant="filled" radius="xl" style={{ fontSize: '0.5rem', background: '#7c3aed', padding: '0 5px' }}>Capital</Badge>}
              {investment.tipoBien && !isCapital && <Badge size="xs" variant="light" color={investment.tipoBien === 'acumulado' ? 'teal' : 'grape'} radius="xl" style={{ fontSize: '0.52rem', textTransform: 'none' }}>{investment.tipoBien === 'acumulado' ? 'Acumulado' : 'Unico'}</Badge>}
              {fuente && <Badge size="xs" variant="dot" color={fuenteColor} radius="xl" style={{ fontSize: '0.55rem', textTransform: 'none' }}>{fuente === 'Accionista' ? 'Fondo accionista' : fuente}</Badge>}
            </div>
            {investment.fuenteDinero === 'Ambos' && (
              <div style={{ display: 'flex', gap: 3, marginTop: 2 }}>
                {parseFloat(investment.splitYefer) > 0 && <Badge size="xs" variant="light" color="blue" radius="xl" style={{ fontSize: '0.53rem', textTransform: 'none' }}>Y: S/.{parseFloat(investment.splitYefer).toFixed(0)}</Badge>}
                {parseFloat(investment.splitFrank) > 0 && <Badge size="xs" variant="light" color="orange" radius="xl" style={{ fontSize: '0.53rem', textTransform: 'none' }}>F: S/.{parseFloat(investment.splitFrank).toFixed(0)}</Badge>}
              </div>
            )}
          </div>
          <Text size="xs" fw={700} style={{ color: amountColor, fontFamily: '"Outfit", sans-serif', flexShrink: 0 }}>
            {isCapital ? '' : '-'}S/.{investment.monto || '0'}
          </Text>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <ActionIcon variant="light" color="blue" radius="xl" size="xs" onClick={onEdit}><IconEdit size={11} /></ActionIcon>
            <ActionIcon variant="light" color="red" radius="xl" size="xs" onClick={onDelete}><IconTrash size={11} /></ActionIcon>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}

/* ================================================================
   VENTAS PENDIENTES
   ================================================================ */
function PendientesSection({ pendingSales, frecuentClients, onRefresh, onAdd, onEdit, onDelete, onComplete }) {
  const active = pendingSales.filter(p => !p.completed).sort((a, b) => {
    const da = getDaysUntil(a.fechaEntrega); const db = getDaysUntil(b.fechaEntrega);
    if (da === null) return 1; if (db === null) return -1; return da - db;
  });
  const completed = pendingSales.filter(p => p.completed).sort((a, b) => parseDateLocal(b.completedDate) - parseDateLocal(a.completedDate));

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
        <IconClock size={18} color={COLORS.navy} />
        <Text size="sm" fw={600} style={{ fontFamily: '"Outfit", sans-serif', color: COLORS.navy }}>Ventas Pendientes</Text>
        {active.length > 0 && <Badge size="sm" color="orange" variant="filled" radius="xl">{active.length}</Badge>}
      </div>
      <Text size="xs" c="dimmed" mb={8} style={{ fontFamily: '"Outfit", sans-serif' }}>
        Registra ventas programadas. Las alertas aparecen cuando se vencen o son para hoy.
      </Text>

      {'Notification' in window && Notification.permission !== 'granted' && (
        <Alert icon={<IconBell size={16} />} color="blue" variant="light" radius="md" mb={8}
          styles={{ message: { fontFamily: '"Outfit", sans-serif', fontSize: '0.72rem' } }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span>Activa notificaciones para recordatorios</span>
            <Button size="xs" radius="xl" variant="light" color="blue" onClick={requestNotificationPermission}
              style={{ fontFamily: '"Outfit", sans-serif' }}>Activar</Button>
          </div>
        </Alert>
      )}

      <Button leftSection={<IconPlus size={14} />} onClick={onAdd}
        radius="xl" size="xs" style={{ background: COLORS.navy, marginBottom: 10, fontFamily: '"Outfit", sans-serif' }}>
        Nueva Venta Pendiente
      </Button>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 16 }}>
        <AnimatePresence>
          {active.map((p) => {
            const days = getDaysUntil(p.fechaEntrega);
            const urgency = getUrgencyColor(days);
            return (
              <motion.div key={p.id} layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -80 }}>
                <Card padding="xs" radius="md" style={{
                  border: `1.5px solid ${days !== null && days <= 0 ? (days < 0 ? '#ff6b6b' : '#ffa94d') : COLORS.borderLight}`,
                  background: days !== null && days < 0 ? '#fff5f5' : days === 0 ? '#fff9f0' : COLORS.white,
                }}>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    {p.foto ? (
                      <div style={{ width: 38, height: 38, borderRadius: 8, overflow: 'hidden', flexShrink: 0 }}>
                        <img src={p.foto} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                      </div>
                    ) : (
                      <div style={{
                        width: 38, height: 38, borderRadius: 8,
                        background: days !== null && days <= 0 ? '#fee6e6' : '#e6f0ff',
                        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                      }}>
                        {days !== null && days <= 0 ? <IconAlertTriangle size={16} color="#c92a2a" /> : <IconClock size={16} color="#2c4a80" />}
                      </div>
                    )}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <Text size="xs" fw={600} lineClamp={1} style={{ fontFamily: '"Outfit", sans-serif' }}>{p.cliente}</Text>
                      <Text size="xs" c="dimmed" lineClamp={1} style={{ fontSize: '0.62rem' }}>{p.producto} - S/.{p.precio || '0'}</Text>
                      <div style={{ display: 'flex', gap: 4, alignItems: 'center', marginTop: 2 }}>
                        <Badge size="xs" color={urgency} variant="filled" radius="xl" style={{ fontSize: '0.56rem' }}>{getUrgencyText(days)}</Badge>
                        {p.fechaEntrega && <Text size="xs" c="dimmed" style={{ fontSize: '0.58rem' }}>{formatDateLocal(p.fechaEntrega, { day: '2-digit', month: '2-digit' })}</Text>}
                      </div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                      <Tooltip label="Completar"><ActionIcon variant="light" color="green" radius="xl" size="xs" onClick={() => onComplete(p.id)}><IconCheck size={11} /></ActionIcon></Tooltip>
                      <ActionIcon variant="light" color="blue" radius="xl" size="xs" onClick={() => onEdit(p)}><IconEdit size={11} /></ActionIcon>
                      <ActionIcon variant="light" color="red" radius="xl" size="xs" onClick={() => onDelete(p.id)}><IconTrash size={11} /></ActionIcon>
                    </div>
                  </div>
                  {p.nota && <Text size="xs" c="dimmed" mt={3} style={{ fontSize: '0.62rem', fontStyle: 'italic' }}>{p.nota}</Text>}
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
        {active.length === 0 && <EmptyState icon={IconCircleCheck} text="Sin ventas pendientes" />}
      </div>

      {completed.length > 0 && (
        <>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
            <IconCircleCheck size={16} color="#2d8a2d" />
            <Text size="xs" fw={600} style={{ fontFamily: '"Outfit", sans-serif', color: '#2d8a2d' }}>Completadas ({completed.length})</Text>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            {completed.slice(0, 10).map(p => (
              <Card key={p.id} padding="xs" radius="md" style={{ border: `1px solid ${COLORS.borderLight}`, background: '#f8fff8', opacity: 0.7 }}>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <IconCircleCheck size={14} color="#2d8a2d" />
                  <Text size="xs" fw={500} style={{ fontFamily: '"Outfit", sans-serif', textDecoration: 'line-through', flex: 1 }}>{p.cliente} - {p.producto}</Text>
                  <Text size="xs" c="dimmed" style={{ fontSize: '0.6rem' }}>S/.{p.precio}</Text>
                  <ActionIcon variant="light" color="red" radius="xl" size="xs" onClick={() => onDelete(p.id)}><IconTrash size={10} /></ActionIcon>
                </div>
              </Card>
            ))}
          </div>
        </>
      )}

      {/* CLIENTES FRECUENTES */}
      <Divider my={14} />
      <ClientesFrecuentesSection clients={frecuentClients} onRefresh={onRefresh} />
    </div>
  );
}

/* ================================================================
   CLIENTES FRECUENTES
   ================================================================ */
function ClientesFrecuentesSection({ clients, onRefresh }) {
  const [showForm, setShowForm] = useState(false);
  const [formName, setFormName] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formFoto, setFormFoto] = useState('');

  const handleAddClient = () => {
    if (!formName.trim()) { notifications.show({ title: 'Error', message: 'El nombre es obligatorio', color: 'red' }); return; }
    addFrecuentClient({ id: generateId(), nombre: formName.trim(), telefono: formPhone.trim(), foto: formFoto, fecha: localToday() });
    setFormName(''); setFormPhone(''); setFormFoto(''); setShowForm(false);
    onRefresh();
    notifications.show({ title: 'Agregado', message: 'Cliente frecuente registrado', color: 'green' });
  };

  const handleFotoAdd = async (file) => {
    if (!file) return;
    try { const b64 = await imageToBase64(file); setFormFoto(b64); }
    catch { notifications.show({ title: 'Error', message: 'Error al cargar foto', color: 'red' }); }
  };

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <IconAddressBook size={16} color={COLORS.navy} />
          <Text size="xs" fw={600} style={{ fontFamily: '"Outfit", sans-serif', color: COLORS.navy }}>Clientes Frecuentes</Text>
        </div>
        <Button leftSection={<IconPlus size={12} />} onClick={() => setShowForm(!showForm)}
          radius="xl" size="xs" variant={showForm ? 'outline' : 'filled'}
          style={{ background: showForm ? 'transparent' : COLORS.orange, fontFamily: '"Outfit", sans-serif',
            color: showForm ? COLORS.orange : 'white', borderColor: COLORS.orange }} compact="true">
          {showForm ? 'Cancelar' : 'Agregar'}
        </Button>
      </div>

      {showForm && (
        <Card padding="sm" radius="md" mb={10} style={{ border: `1px solid ${COLORS.borderLight}`, background: COLORS.offWhite }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <TextInput size="xs" label="Nombre" placeholder="Nombre del cliente" value={formName}
              onChange={(e) => setFormName(e.currentTarget.value)} radius="md" required
              leftSection={<IconUser size={14} />} />
            <TextInput size="xs" label="Telefono (opcional)" placeholder="999 999 999" value={formPhone}
              onChange={(e) => setFormPhone(e.currentTarget.value)} radius="md"
              leftSection={<IconPhone size={14} />} />
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              {formFoto ? (
                <div style={{ position: 'relative' }}>
                  <img src={formFoto} alt="" style={{ width: 48, height: 48, borderRadius: 8, objectFit: 'cover' }} />
                  <ActionIcon size="xs" variant="filled" color="red" radius="xl"
                    style={{ position: 'absolute', top: -4, right: -4 }}
                    onClick={() => setFormFoto('')}><IconX size={8} /></ActionIcon>
                </div>
              ) : (
                <label style={{
                  width: 48, height: 48, borderRadius: 8, background: COLORS.borderLight,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
                  border: '1.5px dashed rgba(0,0,0,0.15)',
                }}>
                  <IconPhoto size={16} color={COLORS.textMuted} />
                  <input type="file" accept="image/*" hidden onChange={(e) => handleFotoAdd(e.target.files[0])} />
                </label>
              )}
              <Text size="xs" c="dimmed" style={{ fontSize: '0.6rem' }}>Foto (opcional)</Text>
            </div>
            <Button size="xs" radius="xl" style={{ background: COLORS.orange }} onClick={handleAddClient}>
              Guardar Cliente
            </Button>
          </div>
        </Card>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        {(clients || []).map(c => (
          <Card key={c.id} padding="xs" radius="md" style={{ border: `1px solid ${COLORS.borderLight}` }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              {c.foto ? (
                <img src={c.foto} alt="" style={{ width: 36, height: 36, borderRadius: '50%', objectFit: 'cover', flexShrink: 0 }} />
              ) : (
                <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#f0f4ff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <IconUser size={16} color="#2c4a80" />
                </div>
              )}
              <div style={{ flex: 1, minWidth: 0 }}>
                <Text size="xs" fw={600} style={{ fontFamily: '"Outfit", sans-serif' }}>{c.nombre}</Text>
                {c.telefono && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
                    <IconPhone size={10} color={COLORS.textMuted} />
                    <Text size="xs" c="dimmed" style={{ fontSize: '0.6rem' }}>{c.telefono}</Text>
                  </div>
                )}
              </div>
              <ActionIcon variant="light" color="red" radius="xl" size="xs"
                onClick={() => { deleteFrecuentClient(c.id); onRefresh(); notifications.show({ title: 'Eliminado', message: 'Cliente eliminado', color: 'red' }); }}>
                <IconTrash size={10} />
              </ActionIcon>
            </div>
          </Card>
        ))}
        {(!clients || clients.length === 0) && <EmptyState icon={IconAddressBook} text="No hay clientes frecuentes" />}
      </div>
    </div>
  );
}

/* ================================================================
   SOCIOS (Yefer & Frank) - con splits correctos
   ================================================================ */
function SociosSection({ ventasPorSocio, sales, investments }) {
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
        <IconUsers size={18} color={COLORS.navy} />
        <Text size="sm" fw={600} style={{ fontFamily: '"Outfit", sans-serif', color: COLORS.navy }}>Ganancias por Socio</Text>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {['Yefer', 'Frank'].map(socio => {
          const data = ventasPorSocio[socio] || { totalVentas: 0, countVentas: 0, totalInversion: 0, countInversion: 0 };
          const gananciaInd = data.totalVentas - data.totalInversion;
          const color = socio === 'Yefer' ? '#2c4a80' : COLORS.orange;
          const bg = socio === 'Yefer' ? '#e6f0ff' : '#fff4e6';

          // Ventas de este socio (directas + su parte de "Ambos")
          const socioSales = sales.filter(s => s.socio === socio || s.socio === 'Ambos').map(s => ({
            ...s,
            montoReal: getSocioAmount(s, socio),
          })).filter(s => s.montoReal > 0);

          return (
            <Card key={socio} padding="md" radius="md" style={{ border: `2px solid ${color}20`, background: bg }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                <div style={{
                  width: 40, height: 40, borderRadius: '50%', background: `${color}15`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', border: `2px solid ${color}30`,
                }}>
                  <IconUserCircle size={22} color={color} />
                </div>
                <div>
                  <Text size="md" fw={700} style={{ fontFamily: '"Playfair Display", serif', color }}>{socio}</Text>
                  <Text size="xs" c="dimmed" style={{ fontFamily: '"Outfit", sans-serif' }}>Socio</Text>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
                <MiniStat icon={IconCash} color="#2d8a2d" label={`Ventas (${data.countVentas})`} value={data.totalVentas} />
                <MiniStat icon={IconReportMoney} color="#c92a2a" label={`Inversion (${data.countInversion})`} value={data.totalInversion} />
                <MiniStat icon={IconWallet} color={gananciaInd >= 0 ? '#2c4a80' : '#e8590c'} label="Ganancia" value={gananciaInd} />
              </div>

              <div style={{ marginTop: 10 }}>
                <Text size="xs" fw={500} c="dimmed" mb={4} style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.62rem' }}>Ultimas ventas</Text>
                {socioSales.slice(0, 5).map(s => (
                  <div key={s.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '2px 0', borderBottom: '1px solid rgba(0,0,0,0.04)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                      <Text size="xs" c="dimmed" style={{ fontSize: '0.6rem' }}>{s.producto}</Text>
                      {s.socio === 'Ambos' && <Badge size="xs" variant="light" color="grape" radius="xl" style={{ fontSize: '0.48rem', textTransform: 'none', padding: '0 4px' }}>compartida</Badge>}
                    </div>
                    <Text size="xs" fw={500} style={{ fontSize: '0.6rem', color: '#2d8a2d' }}>S/.{s.montoReal.toFixed(2)}</Text>
                  </div>
                ))}
                {socioSales.length === 0 && <Text size="xs" c="dimmed" style={{ fontSize: '0.6rem', fontStyle: 'italic' }}>Sin ventas</Text>}
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

function MiniStat({ icon: Icon, color, label, value }) {
  return (
    <div style={{ textAlign: 'center', padding: '6px 2px', background: 'rgba(255,255,255,0.7)', borderRadius: 8 }}>
      <Icon size={14} color={color} style={{ margin: '0 auto 2px' }} />
      <Text size="xs" c="dimmed" style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.55rem' }}>{label}</Text>
      <Text size="sm" fw={700} style={{ color, fontFamily: '"Outfit", sans-serif', fontSize: '0.82rem' }}>S/.{value.toFixed(2)}</Text>
    </div>
  );
}

/* ================================================================
   ACCIONISTAS - Giovany S/.2400, 15% ganancias
   ================================================================ */
function AccionistasSection({ sales, investments, capital, pagosAccionista, onRefresh }) {
  const ACCIONISTA = { nombre: 'Giovany', monto: 2400, porcentaje: 15 };
  const [newCapital, setNewCapital] = useState('');
  const [newCapitalVal, setNewCapitalVal] = useState('');
  const [newCapitalFuente, setNewCapitalFuente] = useState('Yefer');
  const [editingCapital, setEditingCapital] = useState(null); // {id, nombre, valor, fuenteDinero}
  const [showMovimientos, setShowMovimientos] = useState(false);

  // Fondo: total invertido - usado en gastos/costos/capital del accionista
  const invUsado = investments.filter(i => i.fuenteDinero === 'Accionista').reduce((s, i) => s + (parseFloat(i.monto) || 0), 0);
  const costosUsado = sales.filter(s => s.fuenteCostos === 'Accionista').reduce((s, s2) => s + (parseFloat(s2.costosAgregados) || 0), 0);
  const capitalUsado = (capital || []).filter(c => c.fuenteDinero === 'Accionista').reduce((s, c) => s + (parseFloat(c.valor) || 0), 0);
  const totalUsadoFondo = invUsado + costosUsado + capitalUsado;
  const fondoDisponible = ACCIONISTA.monto - totalUsadoFondo;

  // Todos los movimientos del fondo del accionista (para el historial)
  const movimientosFondo = [
    ...investments.filter(i => i.fuenteDinero === 'Accionista').map(i => ({
      id: i.id, fecha: i.fecha, tipo: 'gasto',
      descripcion: i.descripcion || 'Gasto',
      monto: parseFloat(i.monto) || 0,
      categoria: i.categoria || '',
    })),
    ...sales.filter(s => s.fuenteCostos === 'Accionista').map(s => ({
      id: s.id + '_costo', fecha: s.fecha, tipo: 'costo_venta',
      descripcion: `Costo de venta: ${s.producto || ''}`,
      monto: parseFloat(s.costosAgregados) || 0,
      categoria: 'Costo de venta',
    })),
    ...(capital || []).filter(c => c.fuenteDinero === 'Accionista').map(c => ({
      id: c.id + '_cap', fecha: c.fecha, tipo: 'capital',
      descripcion: c.nombre || 'Capital',
      monto: parseFloat(c.valor) || 0,
      categoria: 'Capital / Activo',
    })),
  ].sort((a, b) => parseDateLocal(b.fecha || '1970-01-01') - parseDateLocal(a.fecha || '1970-01-01'));

  // Ganancias mensuales
  const monthlyProfits = useMemo(() => {
    const map = {};
    (sales || []).forEach(s => {
      if (!s.fecha) return;
      const d = parseDateLocal(s.fecha);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      if (!map[key]) map[key] = { ventas: 0, gastos: 0, costos: 0 };
      map[key].ventas += parseFloat(s.precio) || 0;
      map[key].costos += parseFloat(s.costosAgregados) || 0;
    });
    (investments || []).forEach(i => {
      if (!i.fecha) return;
      const d = parseDateLocal(i.fecha);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      if (!map[key]) map[key] = { ventas: 0, gastos: 0, costos: 0 };
      map[key].gastos += parseFloat(i.monto) || 0;
    });
    const names = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    return Object.entries(map).sort(([a], [b]) => b.localeCompare(a)).map(([key, val]) => {
      const [y, m] = key.split('-');
      const ganancia = val.ventas - val.gastos - val.costos;
      const parteGiovany = ganancia > 0 ? ganancia * (ACCIONISTA.porcentaje / 100) : 0;
      const mitadCada = parteGiovany / 2;
      const pagado = (pagosAccionista || []).find(p => p.mes === key);
      return { key, label: `${names[parseInt(m) - 1]} ${y}`, ...val, ganancia, parteGiovany, mitadCada, pagado };
    });
  }, [sales, investments, pagosAccionista]);

  const totalAcumulado = monthlyProfits.reduce((s, m) => s + m.parteGiovany, 0);
  const totalPagado = (pagosAccionista || []).reduce((s, p) => s + (parseFloat(p.monto) || 0), 0);
  const totalPendiente = totalAcumulado - totalPagado;

  const handlePagar = (m) => {
    addPagoAccionista({
      id: generateId(),
      mes: m.key,
      mesLabel: m.label,
      monto: m.parteGiovany,
      mitadYefer: m.mitadCada,
      mitadFrank: m.mitadCada,
      fecha: localToday(),
    });
    onRefresh();
    notifications.show({ title: 'Pagado', message: `${ACCIONISTA.nombre} - ${m.label}: S/.${m.parteGiovany.toFixed(2)}`, color: 'green' });
  };

  const handleEliminarPago = (pagoId) => {
    deletePagoAccionista(pagoId);
    onRefresh();
    notifications.show({ title: 'Eliminado', message: 'Pago eliminado', color: 'red' });
  };

  const handleAddCapital = () => {
    if (!newCapital.trim()) return;
    addCapital({ id: generateId(), nombre: newCapital.trim(), valor: newCapitalVal || '0', fuenteDinero: newCapitalFuente, fecha: localToday() });
    setNewCapital(''); setNewCapitalVal(''); setNewCapitalFuente('Yefer');
    onRefresh();
    notifications.show({ title: 'Agregado', message: 'Capital registrado', color: 'green' });
  };

  const handleSaveEditCapital = () => {
    if (!editingCapital || !editingCapital.nombre.trim()) return;
    updateCapital(editingCapital.id, { nombre: editingCapital.nombre.trim(), valor: editingCapital.valor || '0', fuenteDinero: editingCapital.fuenteDinero || 'Yefer' });
    setEditingCapital(null);
    onRefresh();
    notifications.show({ title: 'Actualizado', message: 'Capital actualizado', color: 'green' });
  };

  return (
    <div>
      {/* INFO GIOVANY */}
      <Card padding="sm" radius="md" mb={10} style={{ background: 'linear-gradient(135deg, #e6f0ff, #f0f4ff)', border: '1px solid #dde4f0' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
          <div style={{ width: 44, height: 44, borderRadius: '50%', background: '#2c4a80', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '3px solid #c8daf0' }}>
            <IconUser size={22} color="white" />
          </div>
          <div style={{ flex: 1 }}>
            <Text size="md" fw={700} style={{ fontFamily: '"Playfair Display", serif', color: '#2c4a80' }}>{ACCIONISTA.nombre}</Text>
            <Text size="xs" c="dimmed" style={{ fontFamily: '"Outfit", sans-serif' }}>Accionista / Inversionista</Text>
          </div>
          <Badge size="lg" variant="filled" color="orange" radius="xl" style={{ fontSize: '0.7rem' }}>{ACCIONISTA.porcentaje}%</Badge>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>
          <div style={{ textAlign: 'center', padding: 8, background: 'white', borderRadius: 8 }}>
            <Text size="xs" c="dimmed" style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.58rem' }}>Invirtio</Text>
            <Text size="sm" fw={700} style={{ color: '#2c4a80' }}>S/.{ACCIONISTA.monto}</Text>
          </div>
          <div style={{ textAlign: 'center', padding: 8, background: 'white', borderRadius: 8 }}>
            <Text size="xs" c="dimmed" style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.58rem' }}>Fondo usado</Text>
            <Text size="sm" fw={700} style={{ color: '#c92a2a' }}>S/.{totalUsadoFondo.toFixed(2)}</Text>
          </div>
          <div style={{ textAlign: 'center', padding: 8, background: 'white', borderRadius: 8 }}>
            <Text size="xs" c="dimmed" style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.58rem' }}>Fondo disponible</Text>
            <Text size="sm" fw={700} style={{ color: fondoDisponible >= 0 ? '#2d8a2d' : '#c92a2a' }}>S/.{fondoDisponible.toFixed(2)}</Text>
          </div>
        </div>
      </Card>

      {/* RESUMEN DE PAGOS */}
      <Card padding="xs" radius="md" mb={10} style={{ background: '#f8fff8', border: '1px solid #d0e8d0' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>
          <div style={{ textAlign: 'center' }}>
            <Text size="xs" c="dimmed" style={{ fontSize: '0.55rem' }}>Total ganado</Text>
            <Text size="sm" fw={700} style={{ color: '#2d8a2d' }}>S/.{totalAcumulado.toFixed(2)}</Text>
          </div>
          <div style={{ textAlign: 'center' }}>
            <Text size="xs" c="dimmed" style={{ fontSize: '0.55rem' }}>Pagado</Text>
            <Text size="sm" fw={700} style={{ color: '#2c4a80' }}>S/.{totalPagado.toFixed(2)}</Text>
          </div>
          <div style={{ textAlign: 'center' }}>
            <Text size="xs" c="dimmed" style={{ fontSize: '0.55rem' }}>Pendiente</Text>
            <Text size="sm" fw={700} style={{ color: totalPendiente > 0 ? '#e8590c' : '#2d8a2d' }}>S/.{totalPendiente.toFixed(2)}</Text>
          </div>
        </div>
      </Card>

      {/* GANANCIAS MENSUALES */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
        <IconPercentage size={16} color={COLORS.navy} />
        <Text size="xs" fw={600} style={{ fontFamily: '"Outfit", sans-serif', color: COLORS.navy }}>
          Ganancias mensuales ({ACCIONISTA.porcentaje}%)
        </Text>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
        {monthlyProfits.map(m => (
          <Card key={m.key} padding="sm" radius="md" style={{
            border: `1px solid ${m.pagado ? '#b8e6b8' : m.ganancia > 0 ? '#e6d8b8' : '#e0e0e0'}`,
            background: m.pagado ? '#f0fff0' : 'white',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
              <Text size="sm" fw={700} style={{ fontFamily: '"Outfit", sans-serif', color: COLORS.navy }}>{m.label}</Text>
              {m.pagado ? (
                <Badge size="xs" variant="filled" color="green" radius="xl">PAGADO</Badge>
              ) : m.ganancia > 0 ? (
                <Badge size="xs" variant="filled" color="orange" radius="xl">PENDIENTE</Badge>
              ) : (
                <Badge size="xs" variant="light" color="gray" radius="xl">Sin ganancia</Badge>
              )}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 4, marginBottom: 6 }}>
              <Text size="xs" c="dimmed" style={{ fontSize: '0.6rem' }}>Ventas: <strong>S/.{m.ventas.toFixed(0)}</strong></Text>
              <Text size="xs" c="dimmed" style={{ fontSize: '0.6rem' }}>Gastos: <strong>S/.{m.gastos.toFixed(0)}</strong></Text>
              <Text size="xs" c="dimmed" style={{ fontSize: '0.6rem' }}>Costos: <strong>S/.{m.costos.toFixed(0)}</strong></Text>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 8px', background: '#f8f9fa', borderRadius: 8, marginBottom: 6 }}>
              <div>
                <Text size="xs" c="dimmed" style={{ fontSize: '0.55rem' }}>Ganancia neta</Text>
                <Text size="xs" fw={700} style={{ color: m.ganancia > 0 ? '#2d8a2d' : '#c92a2a' }}>S/.{m.ganancia.toFixed(2)}</Text>
              </div>
              <div style={{ textAlign: 'center' }}>
                <Text size="xs" c="dimmed" style={{ fontSize: '0.55rem' }}>{ACCIONISTA.porcentaje}% → {ACCIONISTA.nombre}</Text>
                <Text size="sm" fw={700} style={{ color: m.parteGiovany > 0 ? '#e8590c' : '#999' }}>S/.{m.parteGiovany.toFixed(2)}</Text>
              </div>
              <div style={{ textAlign: 'right' }}>
                <Text size="xs" c="dimmed" style={{ fontSize: '0.55rem' }}>Cada socio paga</Text>
                <Text size="xs" fw={600} style={{ color: '#2c4a80' }}>S/.{m.mitadCada.toFixed(2)}</Text>
              </div>
            </div>

            {/* Botones de accion */}
            {m.parteGiovany > 0 && !m.pagado && (
              <Button fullWidth size="xs" radius="xl" leftSection={<IconCash size={14} />}
                style={{ background: '#2d8a2d', fontFamily: '"Outfit", sans-serif' }}
                onClick={() => handlePagar(m)}>
                Pagar {ACCIONISTA.porcentaje}% → S/.{m.parteGiovany.toFixed(2)} (Yefer: S/.{m.mitadCada.toFixed(2)} + Frank: S/.{m.mitadCada.toFixed(2)})
              </Button>
            )}
            {m.pagado && (
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Text size="xs" c="dimmed" style={{ fontSize: '0.58rem', fontStyle: 'italic' }}>
                  Pagado el {m.pagado.fecha} — Yefer: -S/.{m.pagado.mitadYefer?.toFixed(2)} / Frank: -S/.{m.pagado.mitadFrank?.toFixed(2)}
                </Text>
                <ActionIcon variant="light" color="red" radius="xl" size="xs"
                  onClick={() => handleEliminarPago(m.pagado.id)}>
                  <IconTrash size={11} />
                </ActionIcon>
              </div>
            )}
          </Card>
        ))}
        {monthlyProfits.length === 0 && <EmptyState icon={IconPercentage} text="No hay datos de meses aun" />}
      </div>

      {/* CAPITAL / ACTIVOS */}
      <Divider my={14} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <IconTool size={16} color={COLORS.navy} />
        <Text size="xs" fw={600} style={{ fontFamily: '"Outfit", sans-serif', color: COLORS.navy, flex: 1 }}>Capital (Herramientas y Máquinas)</Text>
        {(capital || []).length > 0 && (
          <Badge size="sm" variant="filled" radius="xl" style={{ background: '#7c3aed', fontSize: '0.65rem' }}>
            S/.{(capital || []).reduce((s, c) => s + (parseFloat(c.valor) || 0), 0).toFixed(2)}
          </Badge>
        )}
      </div>

      {/* Capital form */}
      <Card padding="sm" radius="md" mb={10} style={{ background: '#faf8ff', border: '1px solid #e8d8f8' }}>
        <Text size="xs" fw={600} mb={8} style={{ fontFamily: '"Outfit", sans-serif', color: '#7c3aed', fontSize: '0.68rem' }}>+ Agregar activo / herramienta</Text>
        <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
          <TextInput size="xs" placeholder="Ej: Grabadora laser" value={newCapital}
            onChange={(e) => setNewCapital(e.currentTarget.value)} radius="md" style={{ flex: 1 }}
            onKeyDown={(e) => { if (e.key === 'Enter') handleAddCapital(); }} />
          <TextInput size="xs" placeholder="S/." value={newCapitalVal}
            onChange={(e) => setNewCapitalVal(e.currentTarget.value)} radius="md" style={{ width: 80 }}
            onKeyDown={(e) => { if (e.key === 'Enter') handleAddCapital(); }} />
        </div>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <Select size="xs" placeholder="Quien pagó" value={newCapitalFuente}
            onChange={(v) => setNewCapitalFuente(v || 'Yefer')}
            data={FUENTE_DINERO_OPTIONS} radius="md" style={{ flex: 1 }}
            leftSection={<IconMoneybag size={13} />} />
          <Button size="xs" radius="md" style={{ background: '#7c3aed' }} onClick={handleAddCapital}>Agregar</Button>
        </div>
      </Card>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        {(capital || []).map(c => (
          <Card key={c.id} padding="xs" radius="md" style={{ border: `1px solid ${editingCapital?.id === c.id ? '#c4b5fd' : COLORS.borderLight}`, background: editingCapital?.id === c.id ? '#faf8ff' : COLORS.white }}>
            {editingCapital?.id === c.id ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                  <TextInput size="xs" value={editingCapital.nombre}
                    onChange={(e) => setEditingCapital(p => ({ ...p, nombre: e.currentTarget.value }))}
                    radius="md" style={{ flex: 1 }} placeholder="Nombre" />
                  <TextInput size="xs" value={editingCapital.valor}
                    onChange={(e) => setEditingCapital(p => ({ ...p, valor: e.currentTarget.value }))}
                    radius="md" style={{ width: 75 }} placeholder="S/." />
                </div>
                <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                  <Select size="xs" value={editingCapital.fuenteDinero || 'Yefer'}
                    onChange={(v) => setEditingCapital(p => ({ ...p, fuenteDinero: v || 'Yefer' }))}
                    data={FUENTE_DINERO_OPTIONS} radius="md" style={{ flex: 1 }}
                    leftSection={<IconMoneybag size={12} />} />
                  <ActionIcon variant="filled" color="violet" radius="xl" size="sm" onClick={handleSaveEditCapital}><IconCheck size={12} /></ActionIcon>
                  <ActionIcon variant="light" color="gray" radius="xl" size="sm" onClick={() => setEditingCapital(null)}><IconX size={12} /></ActionIcon>
                </div>
              </div>
            ) : (
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <div style={{ width: 32, height: 32, borderRadius: 8,
                  background: c.fuenteDinero === 'Accionista' ? '#fff3cd' : '#f0eeff',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                  border: c.fuenteDinero === 'Accionista' ? '1px solid #ffc107' : '1px solid #e8d8f8',
                }}>
                  <IconBuildingFactory size={14} color={c.fuenteDinero === 'Accionista' ? '#856404' : '#7c3aed'} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <Text size="xs" fw={600} style={{ fontFamily: '"Outfit", sans-serif' }}>{c.nombre}</Text>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 2 }}>
                    <Text size="xs" c="dimmed" style={{ fontSize: '0.56rem' }}>{c.fecha}</Text>
                    {c.fuenteDinero && (
                      <Badge size="xs" variant="light"
                        color={c.fuenteDinero === 'Accionista' ? 'yellow' : c.fuenteDinero === 'Yefer' ? 'blue' : c.fuenteDinero === 'Frank' ? 'orange' : 'grape'}
                        radius="xl" style={{ fontSize: '0.48rem', padding: '1px 5px', textTransform: 'none' }}>
                        {c.fuenteDinero === 'Accionista' ? 'Accionista' : c.fuenteDinero}
                      </Badge>
                    )}
                  </div>
                </div>
                {c.valor && c.valor !== '0' && (
                  <Text size="xs" fw={700} style={{ color: c.fuenteDinero === 'Accionista' ? '#856404' : '#7c3aed', whiteSpace: 'nowrap' }}>
                    S/.{parseFloat(c.valor).toFixed(2)}
                  </Text>
                )}
                <ActionIcon variant="light" color="blue" radius="xl" size="xs"
                  onClick={() => setEditingCapital({ id: c.id, nombre: c.nombre, valor: c.valor || '', fuenteDinero: c.fuenteDinero || 'Yefer' })}><IconEdit size={10} /></ActionIcon>
                <ActionIcon variant="light" color="red" radius="xl" size="xs"
                  onClick={() => { deleteCapital(c.id); onRefresh(); }}><IconTrash size={10} /></ActionIcon>
              </div>
            )}
          </Card>
        ))}
        {(!capital || capital.length === 0) && <EmptyState icon={IconTool} text="No hay capital registrado" />}
      </div>

      {/* HISTORIAL DE MOVIMIENTOS DEL FONDO DEL ACCIONISTA */}
      <Divider my={14} />
      <div
        onClick={() => setShowMovimientos(v => !v)}
        style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: showMovimientos ? 10 : 0, cursor: 'pointer' }}
      >
        <IconShield size={16} color="#856404" />
        <Text size="xs" fw={600} style={{ fontFamily: '"Outfit", sans-serif', color: '#856404', flex: 1 }}>
          Movimientos del fondo accionista
        </Text>
        {movimientosFondo.length > 0 && (
          <Badge size="sm" variant="light" color="yellow" radius="xl" style={{ fontSize: '0.62rem' }}>
            {movimientosFondo.length} movs · S/.{movimientosFondo.reduce((s, m) => s + m.monto, 0).toFixed(2)}
          </Badge>
        )}
        <IconArrowUpRight size={14} color="#856404"
          style={{ transform: showMovimientos ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }} />
      </div>

      <AnimatePresence>
        {showMovimientos && (
          <motion.div
            initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
            style={{ overflow: 'hidden' }}
          >
            {movimientosFondo.length === 0 ? (
              <EmptyState icon={IconShield} text="No hay movimientos del fondo accionista" />
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                {movimientosFondo.map(mov => (
                  <Card key={mov.id} padding="xs" radius="md" style={{
                    border: '1px solid #fde68a',
                    background: mov.tipo === 'capital' ? '#fffbeb' : mov.tipo === 'costo_venta' ? '#fff7ed' : '#fff9f0',
                  }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{
                        width: 30, height: 30, borderRadius: 8, flexShrink: 0,
                        background: mov.tipo === 'capital' ? '#fef3c7' : mov.tipo === 'costo_venta' ? '#ffedd5' : '#fee2e2',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        border: '1px solid rgba(217,119,6,0.2)',
                      }}>
                        {mov.tipo === 'capital' ? <IconTool size={13} color="#d97706" />
                          : mov.tipo === 'costo_venta' ? <IconReceipt size={13} color="#ea580c" />
                          : <IconReportMoney size={13} color="#dc2626" />}
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <Text size="xs" fw={600} style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.72rem', lineHeight: 1.3 }}>
                          {mov.descripcion}
                        </Text>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 2 }}>
                          <Text size="xs" c="dimmed" style={{ fontSize: '0.56rem' }}>{mov.fecha}</Text>
                          <Badge size="xs" variant="light" radius="xl" style={{ fontSize: '0.48rem', padding: '1px 5px',
                            background: mov.tipo === 'capital' ? '#fef9c3' : mov.tipo === 'costo_venta' ? '#fff7ed' : '#fef2f2',
                            color: mov.tipo === 'capital' ? '#854d0e' : mov.tipo === 'costo_venta' ? '#9a3412' : '#991b1b',
                            border: 'none',
                          }}>
                            {mov.tipo === 'capital' ? 'Capital' : mov.tipo === 'costo_venta' ? 'Costo venta' : 'Gasto'}
                            {mov.categoria ? ` · ${mov.categoria}` : ''}
                          </Badge>
                        </div>
                      </div>
                      <Text size="xs" fw={700} style={{ color: '#c92a2a', whiteSpace: 'nowrap' }}>
                        -S/.{mov.monto.toFixed(2)}
                      </Text>
                    </div>
                  </Card>
                ))}
                {/* Total usados */}
                <div style={{
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  padding: '8px 12px', background: '#fef3c7', borderRadius: 10,
                  border: '1px solid #fde68a', marginTop: 4,
                }}>
                  <Text size="xs" fw={600} style={{ fontFamily: '"Outfit", sans-serif', color: '#92400e', fontSize: '0.7rem' }}>
                    Total usado del fondo
                  </Text>
                  <Text size="sm" fw={700} style={{ color: '#92400e' }}>
                    S/.{movimientosFondo.reduce((s, m) => s + m.monto, 0).toFixed(2)} / {ACCIONISTA.monto}
                  </Text>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ================================================================
   SELECTOR DE PRODUCTO CON IMÁGENES
   ================================================================ */
/* ── CachedImg ─────────────────────────────────────────────────────────────
   Muestra la imagen de un producto desde imageCache.
   Se re-renderiza automáticamente cuando llega la foto desde Firebase.
   size: tamaño en px del cuadrado (default 44).
   ──────────────────────────────────────────────────────────────────────── */
function CachedImg({ productId, fallbackImages, size = 44, radius = 8, style = {} }) {
  const cached = useImages(productId);
  const src = (cached?.length ? cached[0] : null) || fallbackImages?.[0] || null;
  const box = { width: size, height: size, borderRadius: radius, flexShrink: 0, overflow: 'hidden', ...style };
  if (src) {
    return <img src={src} alt="" style={{ ...box, objectFit: 'cover', display: 'block' }} loading="lazy" />;
  }
  return (
    <div style={{ ...box, background: COLORS.borderLight, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <IconPhoto size={Math.round(size * 0.36)} color={COLORS.textMuted} />
    </div>
  );
}

function ProductImageSelect({ products, value, onChange }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const ref = useRef(null);

  const selected = products.find(p => p.id === value);
  const filtered = products.filter(p =>
    p.title?.toLowerCase().includes(search.toLowerCase())
  );

  // Pre-cargar imágenes al abrir el dropdown
  useEffect(() => {
    if (!open || !products.length) return;
    import('../utils/imageCache').then(({ preloadImagesInBatches }) => {
      preloadImagesInBatches(products.map(p => p.id), 8);
    });
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  // Cerrar al hacer click fuera
  useEffect(() => {
    const handleClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const handleSelect = (prod) => {
    onChange(prod.id);
    setOpen(false);
    setSearch('');
  };

  const handleClear = (e) => {
    e.stopPropagation();
    onChange(null);
    setSearch('');
  };

  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <div style={{ fontSize: '0.875rem', fontWeight: 500, marginBottom: 4, fontFamily: '"Outfit", sans-serif', color: COLORS.navy }}>
        2. Producto
      </div>
      {/* Trigger */}
      <div
        onClick={() => { if (products.length > 0) setOpen(v => !v); }}
        style={{
          display: 'flex', alignItems: 'center', gap: 8,
          border: `1px solid ${open ? COLORS.orange : COLORS.borderLight}`,
          borderRadius: 8, padding: '7px 10px', cursor: products.length === 0 ? 'not-allowed' : 'pointer',
          background: products.length === 0 ? '#f8f9fa' : 'white',
          transition: 'border-color 0.15s',
          minHeight: 42,
        }}
      >
        <IconDiamond size={16} color={COLORS.textMuted} style={{ flexShrink: 0 }} />
        {selected ? (
          <>
            <CachedImg productId={selected.id} fallbackImages={selected.images} size={28} radius={6} />
            <span style={{ flex: 1, fontFamily: '"Outfit", sans-serif', fontSize: '0.85rem', color: COLORS.navy, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {selected.title} <span style={{ color: COLORS.orange, fontWeight: 700 }}>S/.{selected.price || '0'}</span>
            </span>
            <span onClick={handleClear} style={{ color: COLORS.textMuted, cursor: 'pointer', lineHeight: 1, padding: '0 2px', display: 'flex', alignItems: 'center' }}><IconX size={14} /></span>
          </>
        ) : (
          <span style={{ flex: 1, fontFamily: '"Outfit", sans-serif', fontSize: '0.85rem', color: COLORS.textMuted }}>
            {products.length === 0 ? 'Sin productos' : 'Seleccionar...'}
          </span>
        )}
      </div>

      {/* Dropdown */}
      {open && (
        <div style={{
          position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 9999,
          background: 'white', border: `1px solid ${COLORS.borderLight}`,
          borderRadius: 10, boxShadow: '0 8px 32px rgba(26,39,68,0.14)',
          marginTop: 4, maxHeight: 320, display: 'flex', flexDirection: 'column',
        }}>
          {/* Search */}
          <div style={{ padding: '8px 10px', borderBottom: `1px solid ${COLORS.borderLight}` }}>
            <input
              autoFocus
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar producto..."
              style={{
                width: '100%', border: 'none', outline: 'none',
                fontFamily: '"Outfit", sans-serif', fontSize: '0.82rem',
                color: COLORS.navy, background: 'transparent',
              }}
            />
          </div>
          {/* Options */}
          <div style={{ overflowY: 'auto', flex: 1 }}>
            {filtered.length === 0 && (
              <div style={{ padding: '16px', textAlign: 'center', color: COLORS.textMuted, fontSize: '0.78rem', fontFamily: '"Outfit", sans-serif' }}>
                Sin resultados
              </div>
            )}
            {filtered.map((prod) => (
              <div
                key={prod.id}
                onClick={() => handleSelect(prod)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  padding: '8px 12px', cursor: 'pointer',
                  background: prod.id === value ? '#f0f4ff' : 'white',
                  transition: 'background 0.1s',
                }}
                onMouseEnter={(e) => { if (prod.id !== value) e.currentTarget.style.background = '#fafbff'; }}
                onMouseLeave={(e) => { if (prod.id !== value) e.currentTarget.style.background = 'white'; }}
              >
                {/* Thumbnail */}
                <CachedImg productId={prod.id} fallbackImages={prod.images} size={44} radius={8} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.82rem', fontWeight: 600, color: COLORS.navy, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {prod.title}
                  </div>
                  <div style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.72rem', color: COLORS.orange, fontWeight: 700 }}>
                    S/.{prod.price || '0'}
                  </div>
                </div>
                {prod.id === value && (
                  <IconCheck size={16} color={COLORS.orange} />
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ================================================================
   MODAL: REGISTRAR VENTA
   - Selector Categoria → Producto (auto-llena foto y precio)
   - Socio: Yefer / Frank / Ambos (con split)
   ================================================================ */
function SaleFormModal({ open, sale, categories, products, onClose, onSave }) {
  const [form, setForm] = useState({
    producto: '', fecha: '', precio: '', foto: '', socio: '', medioEntrega: 'Contra entrega',
    categoryId: '', productId: '', splitYefer: '', splitFrank: '',
  });
  const [selectedTalla, setSelectedTalla] = useState({ varon: '', dama: '' });
  const [productInv, setProductInv] = useState(null); // inventario del producto seleccionado

  React.useEffect(() => {
    if (sale) {
      setForm({
        producto: sale.producto || '', fecha: sale.fecha || '', precio: sale.precio || '',
        foto: sale.foto || '', socio: sale.socio || '', medioEntrega: sale.medioEntrega || 'Contra entrega',
        categoryId: sale.categoryId || '', productId: sale.productId || '',
        splitYefer: sale.splitYefer || '', splitFrank: sale.splitFrank || '',
        costosAgregados: sale.costosAgregados || '', detalleCostos: sale.detalleCostos || '',
        fuenteCostos: sale.fuenteCostos || '',
        rebaja: sale.rebaja || '', montoRebaja: sale.montoRebaja || '',
      });
    } else {
      const today = localToday();
      setForm({ producto: '', fecha: today, precio: '', foto: '', socio: '', medioEntrega: 'Contra entrega', categoryId: '', productId: '', splitYefer: '', splitFrank: '', costosAgregados: '', detalleCostos: '', fuenteCostos: '', rebaja: '', montoRebaja: '' });
    }
    setSelectedTalla({ varon: '', dama: '' });
    setProductInv(null);
  }, [sale, open]);

  // Cargar inventario del producto seleccionado
  React.useEffect(() => {
    if (!form.productId) { setProductInv(null); setSelectedTalla({ varon: '', dama: '' }); return; }
    getProductInventory(form.productId).then(inv => setProductInv(inv));
  }, [form.productId]);

  const filteredProducts = useMemo(() => {
    if (!form.categoryId) return [];
    return products.filter(p => p.categoryId === form.categoryId);
  }, [form.categoryId, products]);

  const handleProductSelect = (productId) => {
    const prod = products.find(p => p.id === productId);
    if (prod) {
      import('../utils/imageCache').then(({ getImages }) => {
        const imgs = getImages(prod.id);
        const foto = (imgs?.length ? imgs[0] : null) || prod.images?.[0] || '';
        setForm(p => ({ ...p, productId, producto: prod.title || '', precio: prod.price || '', foto }));
      });
    } else {
      setForm(p => ({ ...p, productId: '', producto: '', precio: '', foto: '' }));
    }
  };

  // Auto-dividir mitad cuando seleccionan "Ambos"
  const handleSocioChange = (v) => {
    setForm(p => {
      const newForm = { ...p, socio: v || '' };
      if (v === 'Ambos' && p.precio) {
        const half = (parseFloat(p.precio) / 2).toFixed(2);
        newForm.splitYefer = half;
        newForm.splitFrank = half;
      } else {
        newForm.splitYefer = '';
        newForm.splitFrank = '';
      }
      return newForm;
    });
  };

  const handleSubmit = () => {
    if (!form.producto.trim()) { notifications.show({ title: 'Error', message: 'Selecciona un producto', color: 'red' }); return; }
    if (!form.precio) { notifications.show({ title: 'Error', message: 'El precio es obligatorio', color: 'red' }); return; }
    if (form.socio === 'Ambos') {
      const sy = parseFloat(form.splitYefer) || 0;
      const sf = parseFloat(form.splitFrank) || 0;
      const total = parseFloat(form.precio) || 0;
      if (Math.abs((sy + sf) - total) > 0.5) {
        notifications.show({ title: 'Error', message: `La suma de partes (S/.${(sy + sf).toFixed(2)}) no coincide con el total (S/.${total.toFixed(2)})`, color: 'red' });
        return;
      }
    }
    if (sale) {
      updateSale(sale.id, form);
      notifications.show({ title: 'Actualizado', message: 'Venta actualizada', color: 'green' });
    } else {
      // Construir lista de tallas vendidas (puede ser una de varón, una de dama, ambas, o ninguna)
      const tallasVendidas = [selectedTalla.varon, selectedTalla.dama].filter(Boolean);
      addSale({ id: generateId(), ...form, tallaSold: tallasVendidas.length === 1 ? tallasVendidas[0] : tallasVendidas.length > 1 ? tallasVendidas : null });
      // Descontar cada talla del inventario
      if (form.productId && tallasVendidas.length > 0) {
        Promise.all(tallasVendidas.map(t => deductInventory(form.productId, t))).then(() => {
          checkAndSyncSoldOut(form.productId).then(isOut => {
            if (isOut) {
              import('../utils/store').then(({ toggleSoldOut, loadStore }) => {
                const data = loadStore();
                const prod = (data.products || []).find(p => p.id === form.productId);
                if (prod && !prod.soldOut) toggleSoldOut(form.productId);
              });
            }
          });
        });
      } else if (form.productId && tallasVendidas.length === 0) {
        // Sin talla específica — descontar del stock general
        deductInventory(form.productId, null);
      }
      notifications.show({ title: 'Venta registrada', message: 'Stock descontado del inventario', color: 'green' });
    }
    onSave();
  };

  return (
    <Modal opened={open} onClose={onClose} title={sale ? 'Editar Venta' : 'Registrar Venta'}
      centered size="md" radius="lg"
      styles={{ title: { fontFamily: '"Playfair Display", serif', fontWeight: 600, color: COLORS.navy } }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>

        <Select label="1. Categoria" placeholder="Seleccionar..."
          value={form.categoryId}
          onChange={(v) => setForm(p => ({ ...p, categoryId: v || '', productId: '', producto: '', precio: '', foto: '' }))}
          data={categories.map(c => ({ value: c.id, label: c.name }))}
          radius="md" clearable searchable leftSection={<IconCategory size={16} />} />

        {form.categoryId && (
          <ProductImageSelect
            products={filteredProducts}
            value={form.productId}
            onChange={handleProductSelect}
          />
        )}

        {/* Preview producto */}
        {form.producto && (
          <Card padding="sm" radius="md" style={{ background: COLORS.offWhite, border: `1px solid ${COLORS.borderLight}` }}>
            {form.foto ? (
              <div style={{ width: '100%', borderRadius: 10, overflow: 'hidden', marginBottom: 8, maxHeight: 220 }}>
                <img src={form.foto} alt={form.producto} style={{ width: '100%', height: 220, objectFit: 'cover', display: 'block' }} />
              </div>
            ) : (
              <div style={{ width: '100%', height: 100, borderRadius: 10, background: COLORS.borderLight, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}>
                <IconPhoto size={32} color={COLORS.textMuted} />
              </div>
            )}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: 4 }}>
              <Text size="sm" fw={600} style={{ fontFamily: '"Outfit", sans-serif', color: COLORS.navy }}>{form.producto}</Text>
              <Text size="sm" fw={700} style={{ color: COLORS.orange, fontFamily: '"Outfit", sans-serif' }}>S/. {form.precio}</Text>
            </div>
          </Card>
        )}

        {/* Selector de talla para anillos */}
        {productInv?.isRing && form.productId && (() => {
          const selectedProd = products.find(p => p.id === form.productId);
          const tallasV = selectedProd?.tallasVaron || selectedProd?.tallas || [];
          const tallasD = selectedProd?.tallasDama || [];
          if (!tallasV.length && !tallasD.length) return null;
          return (
            <Card padding="sm" radius="md" style={{ background: '#f8f9ff', border: '1px solid rgba(44,74,128,0.15)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <IconDiamond size={15} color={COLORS.navy} />
                <Text size="xs" fw={700} mb={8} style={{ fontFamily: '"Outfit",sans-serif', color: COLORS.navy }}>
                  ¿Qué talla se vendió?
                </Text>
              </div>
              {tallasV.length > 0 && (
                <div style={{ marginBottom: tallasD.length > 0 ? 10 : 0 }}>
                  <Text size="xs" mb={6} style={{ fontFamily: '"Outfit",sans-serif', color: '#2c4a80', fontWeight: 600 }}>Varón</Text>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    {[...tallasV].sort((a,b) => parseFloat(a)-parseFloat(b) || String(a).localeCompare(String(b))).map(t => {
                      const key = `V-${t}`;
                      const stock = getSizeStock(productInv, key);
                      const out = stock === 0;
                      const sel = selectedTalla.varon === key;
                      return (
                        <button key={key} onClick={() => !out && setSelectedTalla(p => ({ ...p, varon: sel ? '' : key }))}
                          style={{
                            fontFamily: '"Outfit",sans-serif', fontSize: '0.78rem', fontWeight: 600,
                            padding: out ? '5px 12px' : '6px 14px', borderRadius: 10,
                            border: sel ? '2px solid #2c4a80' : out ? '1.5px solid #e11d4833' : '1.5px solid #2c4a8033',
                            background: sel ? '#2c4a80' : out ? '#fff5f5' : '#eef2ff',
                            color: sel ? 'white' : out ? '#e11d48' : '#2c4a80',
                            cursor: out ? 'not-allowed' : 'pointer',
                            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1,
                          }}>
                          <span>{t}</span>
                          {stock !== null && <span style={{ fontSize: '0.5rem', opacity: 0.8 }}>{out ? 'AGOTADO' : `${stock} uds`}</span>}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
              {tallasD.length > 0 && (
                <div>
                  <Text size="xs" mb={6} mt={tallasV.length > 0 ? 8 : 0} style={{ fontFamily: '"Outfit",sans-serif', color: '#c2255c', fontWeight: 600 }}>Dama</Text>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    {[...tallasD].sort((a,b) => parseFloat(a)-parseFloat(b) || String(a).localeCompare(String(b))).map(t => {
                      const key = `D-${t}`;
                      const stock = getSizeStock(productInv, key);
                      const out = stock === 0;
                      const sel = selectedTalla.dama === key;
                      return (
                        <button key={key} onClick={() => !out && setSelectedTalla(p => ({ ...p, dama: sel ? '' : key }))}
                          style={{
                            fontFamily: '"Outfit",sans-serif', fontSize: '0.78rem', fontWeight: 600,
                            padding: out ? '5px 12px' : '6px 14px', borderRadius: 10,
                            border: sel ? '2px solid #c2255c' : out ? '1.5px solid #e11d4833' : '1.5px solid #c2255c33',
                            background: sel ? '#c2255c' : out ? '#fff5f5' : '#fff0f6',
                            color: sel ? 'white' : out ? '#e11d48' : '#c2255c',
                            cursor: out ? 'not-allowed' : 'pointer',
                            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1,
                          }}>
                          <span>{t}</span>
                          {stock !== null && <span style={{ fontSize: '0.5rem', opacity: 0.8 }}>{out ? 'AGOTADO' : `${stock} uds`}</span>}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
              {(selectedTalla.varon || selectedTalla.dama) && (
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: 6, marginTop: 8 }}>
                  <IconCheck size={13} color={COLORS.orange} style={{ marginTop: 2, flexShrink: 0 }} />
                  <div>
                    {selectedTalla.varon && (
                      <Text size="xs" style={{ fontFamily: '"Outfit",sans-serif', color: '#2c4a80', fontWeight: 600 }}>
                        Varón talla {selectedTalla.varon.slice(2)} — se descontará 1 unidad
                      </Text>
                    )}
                    {selectedTalla.dama && (
                      <Text size="xs" style={{ fontFamily: '"Outfit",sans-serif', color: '#c2255c', fontWeight: 600 }}>
                        Dama talla {selectedTalla.dama.slice(2)} — se descontará 1 unidad
                      </Text>
                    )}
                    {selectedTalla.varon && selectedTalla.dama && (
                      <Text size="xs" c="dimmed" style={{ fontFamily: '"Outfit",sans-serif', fontSize: '0.6rem', marginTop: 2 }}>
                        Se descontarán 2 unidades en total (1 varón + 1 dama)
                      </Text>
                    )}
                  </div>
                </div>
              )}
            </Card>
          );
        })()}

        <TextInput label="Precio de venta (S/.)" placeholder="0.00" value={form.precio}
          onChange={(e) => {
            const newPrice = e.currentTarget.value;
            setForm(p => {
              const updated = { ...p, precio: newPrice };
              if (p.socio === 'Ambos' && newPrice) {
                const half = (parseFloat(newPrice) / 2).toFixed(2);
                updated.splitYefer = half;
                updated.splitFrank = half;
              }
              return updated;
            });
          }}
          radius="md" leftSection={<IconCash size={16} />} />

        <TextInput label="Fecha" type="date" value={form.fecha}
          onChange={(e) => setForm(p => ({ ...p, fecha: e.currentTarget.value }))} radius="md" leftSection={<IconCalendar size={16} />} />

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          <Select label="Socio / Vendedor" placeholder="Seleccionar" value={form.socio}
            onChange={handleSocioChange}
            data={SOCIOS_OPTIONS} radius="md" clearable leftSection={<IconUser size={16} />} />
          <Select label="Medio de Entrega" value={form.medioEntrega}
            onChange={(v) => setForm(p => ({ ...p, medioEntrega: v || '' }))}
            data={MEDIOS_ENTREGA.map(m => ({ value: m, label: m }))}
            radius="md" clearable leftSection={<IconTruckDelivery size={16} />} />
        </div>

        {/* SPLIT entre socios */}
        {form.socio === 'Ambos' && (
          <Card padding="sm" radius="md" style={{ background: '#f8f0ff', border: '1px solid #e8d8f8' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
              <IconArrowsSplit size={16} color="#7c3aed" />
              <Text size="xs" fw={600} style={{ fontFamily: '"Outfit", sans-serif', color: '#7c3aed' }}>Reparto de ganancia</Text>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <TextInput size="xs" label="Parte de Yefer (S/.)" placeholder="0.00"
                value={form.splitYefer}
                onChange={(e) => setForm(p => ({ ...p, splitYefer: e.currentTarget.value }))}
                radius="md" leftSection={<IconUser size={14} />}
                styles={{ label: { fontSize: '0.7rem', color: '#2c4a80' } }} />
              <TextInput size="xs" label="Parte de Frank (S/.)" placeholder="0.00"
                value={form.splitFrank}
                onChange={(e) => setForm(p => ({ ...p, splitFrank: e.currentTarget.value }))}
                radius="md" leftSection={<IconUser size={14} />}
                styles={{ label: { fontSize: '0.7rem', color: COLORS.orange } }} />
            </div>
            {form.precio && (
              <Text size="xs" c="dimmed" mt={4} ta="center" style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.65rem' }}>
                Total: S/.{form.precio} | Suma: S/.{((parseFloat(form.splitYefer) || 0) + (parseFloat(form.splitFrank) || 0)).toFixed(2)}
              </Text>
            )}
          </Card>
        )}

        {/* COSTOS AGREGADOS */}
        <Card padding="sm" radius="md" style={{ background: '#fff8f0', border: '1px solid #f0e0cc' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
            <IconCoins size={16} color="#e8590c" />
            <Text size="xs" fw={600} style={{ fontFamily: '"Outfit", sans-serif', color: '#e8590c' }}>Costos agregados (opcional)</Text>
          </div>
          <Text size="xs" c="dimmed" mb={6} style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.62rem' }}>
            Pasajes, empaque, caja, etc. Se resta de la ganancia.
          </Text>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <TextInput size="xs" label="Monto (S/.)" placeholder="0.00"
              value={form.costosAgregados}
              onChange={(e) => setForm(p => ({ ...p, costosAgregados: e.currentTarget.value }))}
              radius="md" leftSection={<IconCoins size={14} />}
              styles={{ label: { fontSize: '0.7rem' } }} />
            <TextInput size="xs" label="Detalle" placeholder="Ej: Pasaje + caja"
              value={form.detalleCostos}
              onChange={(e) => setForm(p => ({ ...p, detalleCostos: e.currentTarget.value }))}
              radius="md"
              styles={{ label: { fontSize: '0.7rem' } }} />
          </div>
          {form.costosAgregados && parseFloat(form.costosAgregados) > 0 && (
            <Select size="xs" label="Quien paga este costo?" placeholder="Seleccionar..."
              value={form.fuenteCostos}
              onChange={(v) => setForm(p => ({ ...p, fuenteCostos: v || '' }))}
              data={[
                { value: 'Yefer', label: 'Yefer' },
                { value: 'Frank', label: 'Frank' },
                { value: 'Accionista', label: 'Dinero del accionista' },
              ]}
              radius="md" clearable leftSection={<IconWallet size={14} />}
              styles={{ label: { fontSize: '0.7rem' } }} />
          )}
        </Card>

        {/* REBAJA */}
        <Card padding="sm" radius="md" style={{ background: '#f0fff4', border: '1px solid #c8e6d0' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
            <IconPercentage size={16} color="#2d8a2d" />
            <Text size="xs" fw={600} style={{ fontFamily: '"Outfit", sans-serif', color: '#2d8a2d' }}>Rebaja aplicada (opcional)</Text>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <Select size="xs" label="Hubo rebaja?" value={form.rebaja}
              onChange={(v) => setForm(p => ({ ...p, rebaja: v || '', montoRebaja: v === 'no' ? '' : p.montoRebaja }))}
              data={[{ value: 'si', label: 'Si' }, { value: 'no', label: 'No' }]}
              radius="md" clearable
              styles={{ label: { fontSize: '0.7rem' } }} />
            {form.rebaja === 'si' && (
              <TextInput size="xs" label="Monto rebajado (S/.)" placeholder="0.00"
                value={form.montoRebaja}
                onChange={(e) => setForm(p => ({ ...p, montoRebaja: e.currentTarget.value }))}
                radius="md" leftSection={<IconPercentage size={14} />}
                styles={{ label: { fontSize: '0.7rem' } }} />
            )}
          </div>
          {form.rebaja === 'si' && form.montoRebaja && form.precio && (
            <Text size="xs" c="dimmed" mt={4} style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.62rem' }}>
              Precio original era S/.{(parseFloat(form.precio) + parseFloat(form.montoRebaja || 0)).toFixed(2)}, se rebajo S/.{form.montoRebaja}
            </Text>
          )}
        </Card>

        <Button onClick={handleSubmit} radius="xl" mt="xs"
          style={{ background: COLORS.navy, fontFamily: '"Outfit", sans-serif' }}>
          {sale ? 'Guardar Cambios' : 'Registrar Venta'}
        </Button>
      </div>
    </Modal>
  );
}

/* ================================================================
   MODAL: REGISTRAR GASTO / INVERSION
   - Fuente del dinero: Yefer / Frank / Ambos (con split) / Accionista
   ================================================================ */
function InvestmentFormModal({ open, investment, totalAccionistas, totalUsadoAccionista, onClose, onSave }) {
  const [form, setForm] = useState({
    descripcion: '', fecha: '', monto: '', categoria: '', nota: '',
    fuenteDinero: '', splitYefer: '', splitFrank: '', tipoBien: '', esCapital: false,
  });

  React.useEffect(() => {
    if (investment) {
      setForm({
        descripcion: investment.descripcion || '', fecha: investment.fecha || '',
        monto: investment.monto || '', categoria: investment.categoria || '',
        nota: investment.nota || '', fuenteDinero: investment.fuenteDinero || investment.socio || '',
        splitYefer: investment.splitYefer || '', splitFrank: investment.splitFrank || '',
        tipoBien: investment.tipoBien || '', esCapital: !!investment.esCapital,
      });
    } else {
      const today = localToday();
      setForm({ descripcion: '', fecha: today, monto: '', categoria: '', nota: '', fuenteDinero: '', splitYefer: '', splitFrank: '', tipoBien: '', esCapital: false });
    }
  }, [investment, open]);

  const handleFuenteChange = (v) => {
    setForm(p => {
      const updated = { ...p, fuenteDinero: v || '' };
      if (v === 'Ambos' && p.monto) {
        const half = (parseFloat(p.monto) / 2).toFixed(2);
        updated.splitYefer = half;
        updated.splitFrank = half;
      } else {
        updated.splitYefer = '';
        updated.splitFrank = '';
      }
      return updated;
    });
  };

  const fondoDisponible = totalAccionistas - totalUsadoAccionista;

  const handleSubmit = () => {
    if (!form.descripcion.trim()) { notifications.show({ title: 'Error', message: 'La descripcion es obligatoria', color: 'red' }); return; }
    if (!form.monto) { notifications.show({ title: 'Error', message: 'El monto es obligatorio', color: 'red' }); return; }
    if (form.fuenteDinero === 'Ambos') {
      const sy = parseFloat(form.splitYefer) || 0;
      const sf = parseFloat(form.splitFrank) || 0;
      const total = parseFloat(form.monto) || 0;
      if (Math.abs((sy + sf) - total) > 0.5) {
        notifications.show({ title: 'Error', message: `La suma de partes (S/.${(sy + sf).toFixed(2)}) no coincide con el total (S/.${total.toFixed(2)})`, color: 'red' });
        return;
      }
    }
    if (form.fuenteDinero === 'Accionista' && fondoDisponible < parseFloat(form.monto || 0)) {
      notifications.show({ title: 'Aviso', message: `Fondo accionista disponible: S/.${fondoDisponible.toFixed(2)}. Estas usando mas de lo disponible.`, color: 'yellow' });
    }
    // Guardar con socio = fuenteDinero para compatibilidad
    const saveData = { ...form, socio: form.fuenteDinero };
    if (investment) {
      updateInvestment(investment.id, saveData);
      notifications.show({ title: 'Actualizado', message: 'Gasto actualizado', color: 'green' });
    } else {
      addInvestment({ id: generateId(), ...saveData });
      notifications.show({ title: 'Registrado', message: 'Gasto registrado', color: 'green' });
    }
    onSave();
  };

  return (
    <Modal opened={open} onClose={onClose} title={investment ? 'Editar Gasto' : 'Registrar Gasto'}
      centered size="md" radius="lg"
      styles={{ title: { fontFamily: '"Playfair Display", serif', fontWeight: 600, color: COLORS.navy } }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <TextInput label="Descripcion" placeholder="Ej: Compra de 50 cajas" value={form.descripcion}
          onChange={(e) => setForm(p => ({ ...p, descripcion: e.currentTarget.value }))} required radius="md"
          leftSection={<IconPackage size={16} />} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          <TextInput label="Fecha" type="date" value={form.fecha}
            onChange={(e) => setForm(p => ({ ...p, fecha: e.currentTarget.value }))} radius="md" leftSection={<IconCalendar size={16} />} />
          <TextInput label="Monto (S/.)" placeholder="0.00" value={form.monto}
            onChange={(e) => {
              const newMonto = e.currentTarget.value;
              setForm(p => {
                const updated = { ...p, monto: newMonto };
                if (p.fuenteDinero === 'Ambos' && newMonto) {
                  const half = (parseFloat(newMonto) / 2).toFixed(2);
                  updated.splitYefer = half;
                  updated.splitFrank = half;
                }
                return updated;
              });
            }}
            required radius="md" leftSection={<IconCash size={16} />} />
        </div>

        <Select label="Categoria de gasto" placeholder="Seleccionar" value={form.categoria}
          onChange={(v) => setForm(p => ({
            ...p, categoria: v || '',
            // Si selecciona Herramientas → auto-marcar como capital
            esCapital: v === 'Herramientas' ? true : p.esCapital,
          }))}
          data={CATEGORIAS_INVERSION.map(c => ({ value: c, label: c }))}
          radius="md" clearable leftSection={<IconBox size={16} />} />

        <Select label="Tipo de bien" placeholder="Seleccionar tipo" value={form.tipoBien}
          onChange={(v) => setForm(p => ({ ...p, tipoBien: v || '' }))}
          data={[
            { value: 'acumulado', label: 'Bien acumulado (cajas, flores, bolsas, etc.)' },
            { value: 'unico', label: 'Bien de un solo uso (anillo, tablet, etc.)' },
          ]}
          radius="md" clearable leftSection={<IconPackage size={16} />} />

        {/* FUENTE DEL DINERO */}
        <Select label="De donde sale el dinero" placeholder="Quien paga" value={form.fuenteDinero}
          onChange={handleFuenteChange}
          data={FUENTE_DINERO_OPTIONS}
          radius="md" clearable leftSection={<IconMoneybag size={16} />}
          description={form.fuenteDinero === 'Accionista' ? `Fondo disponible: S/.${fondoDisponible.toFixed(2)}` : ''} />

        {/* SPLIT entre socios para gastos */}
        {form.fuenteDinero === 'Ambos' && (
          <Card padding="sm" radius="md" style={{ background: '#f8f0ff', border: '1px solid #e8d8f8' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
              <IconArrowsSplit size={16} color="#7c3aed" />
              <Text size="xs" fw={600} style={{ fontFamily: '"Outfit", sans-serif', color: '#7c3aed' }}>Cuanto pone cada socio</Text>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <TextInput size="xs" label="Yefer pone (S/.)" placeholder="0.00"
                value={form.splitYefer}
                onChange={(e) => setForm(p => ({ ...p, splitYefer: e.currentTarget.value }))}
                radius="md" leftSection={<IconUser size={14} />}
                styles={{ label: { fontSize: '0.7rem', color: '#2c4a80' } }} />
              <TextInput size="xs" label="Frank pone (S/.)" placeholder="0.00"
                value={form.splitFrank}
                onChange={(e) => setForm(p => ({ ...p, splitFrank: e.currentTarget.value }))}
                radius="md" leftSection={<IconUser size={14} />}
                styles={{ label: { fontSize: '0.7rem', color: COLORS.orange } }} />
            </div>
            {form.monto && (
              <Text size="xs" c="dimmed" mt={4} ta="center" style={{ fontFamily: '"Outfit", sans-serif', fontSize: '0.65rem' }}>
                Total: S/.{form.monto} | Suma: S/.{((parseFloat(form.splitYefer) || 0) + (parseFloat(form.splitFrank) || 0)).toFixed(2)}
              </Text>
            )}
          </Card>
        )}

        <Textarea label="Nota (opcional)" placeholder="Detalles extra..." value={form.nota}
          onChange={(e) => setForm(p => ({ ...p, nota: e.currentTarget.value }))} radius="md" rows={2} />
        <Button onClick={handleSubmit} radius="xl" mt="xs"
          style={{ background: '#c92a2a', fontFamily: '"Outfit", sans-serif' }}>
          {investment ? 'Guardar Cambios' : 'Registrar Gasto'}
        </Button>
      </div>
    </Modal>
  );
}

/* ================================================================
   MODAL: ACCIONISTA
   ================================================================ */
/* ================================================================
   MODAL: VENTA PENDIENTE
   ================================================================ */
function PendingSaleFormModal({ open, pending, categories, products, onClose, onSave }) {
  const [form, setForm] = useState({
    cliente: '', producto: '', precio: '', fechaEntrega: '', nota: '',
    categoryId: '', productId: '', foto: '',
  });

  React.useEffect(() => {
    if (pending) {
      setForm({
        cliente: pending.cliente || '', producto: pending.producto || '',
        precio: pending.precio || '', fechaEntrega: pending.fechaEntrega || '',
        nota: pending.nota || '', categoryId: pending.categoryId || '',
        productId: pending.productId || '', foto: pending.foto || '',
      });
    } else {
      setForm({ cliente: '', producto: '', precio: '', fechaEntrega: '', nota: '', categoryId: '', productId: '', foto: '' });
    }
  }, [pending, open]);

  const filteredProducts = useMemo(() => {
    if (!form.categoryId) return [];
    return products.filter(p => p.categoryId === form.categoryId);
  }, [form.categoryId, products]);

  const handleProductSelect = (productId) => {
    const prod = products.find(p => p.id === productId);
    if (prod) {
      import('../utils/imageCache').then(({ getImages }) => {
        const imgs = getImages(prod.id);
        const foto = (imgs?.length ? imgs[0] : null) || prod.images?.[0] || '';
        setForm(p => ({ ...p, productId, producto: prod.title || '', precio: prod.price || '', foto }));
      });
    } else {
      setForm(p => ({ ...p, productId: '', producto: '', precio: '', foto: '' }));
    }
  };

  const handleSubmit = () => {
    if (!form.cliente.trim()) { notifications.show({ title: 'Error', message: 'Nombre del cliente obligatorio', color: 'red' }); return; }
    if (!form.producto.trim()) { notifications.show({ title: 'Error', message: 'Selecciona un producto', color: 'red' }); return; }
    if (pending) {
      updatePendingSale(pending.id, form);
      notifications.show({ title: 'Actualizado', message: 'Pendiente actualizado', color: 'green' });
    } else {
      addPendingSale({ id: generateId(), ...form, completed: false });
      notifications.show({ title: 'Registrado', message: 'Venta pendiente registrada', color: 'green' });
    }
    onSave();
  };

  return (
    <Modal opened={open} onClose={onClose} title={pending ? 'Editar Pendiente' : 'Nueva Venta Pendiente'}
      centered size="md" radius="lg"
      styles={{ title: { fontFamily: '"Playfair Display", serif', fontWeight: 600, color: COLORS.navy } }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <TextInput label="Nombre del cliente" placeholder="Ej: Juan Perez" value={form.cliente}
          onChange={(e) => setForm(p => ({ ...p, cliente: e.currentTarget.value }))} required radius="md" leftSection={<IconUser size={16} />} />

        <Select label="Categoria" placeholder="Seleccionar"
          value={form.categoryId}
          onChange={(v) => setForm(p => ({ ...p, categoryId: v || '', productId: '', producto: '', precio: '', foto: '' }))}
          data={categories.map(c => ({ value: c.id, label: c.name }))}
          radius="md" clearable searchable leftSection={<IconCategory size={16} />} />

        {form.categoryId && (
          <Select label="Producto" placeholder={filteredProducts.length === 0 ? 'Sin productos' : 'Seleccionar...'}
            value={form.productId} onChange={handleProductSelect}
            data={filteredProducts.map(p => ({ value: p.id, label: `${p.title} - S/.${p.price || '0'}` }))}
            radius="md" clearable searchable leftSection={<IconDiamond size={16} />}
            disabled={filteredProducts.length === 0} />
        )}

        {form.producto && form.foto && (
          <Card padding="xs" radius="md" style={{ background: COLORS.offWhite, border: `1px solid ${COLORS.borderLight}` }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <div style={{ width: 40, height: 40, borderRadius: 6, overflow: 'hidden', flexShrink: 0 }}>
                <img src={form.foto} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              </div>
              <div>
                <Text size="xs" fw={600}>{form.producto}</Text>
                <Text size="xs" fw={600} style={{ color: COLORS.orange }}>S/. {form.precio}</Text>
              </div>
            </div>
          </Card>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          <TextInput label="Precio (S/.)" placeholder="0.00" value={form.precio}
            onChange={(e) => setForm(p => ({ ...p, precio: e.currentTarget.value }))} radius="md" leftSection={<IconCash size={16} />} />
          <TextInput label="Fecha de entrega" type="date" value={form.fechaEntrega}
            onChange={(e) => setForm(p => ({ ...p, fechaEntrega: e.currentTarget.value }))} radius="md" leftSection={<IconCalendar size={16} />} />
        </div>

        <Textarea label="Nota (opcional)" placeholder="Detalles, direccion, etc." value={form.nota}
          onChange={(e) => setForm(p => ({ ...p, nota: e.currentTarget.value }))} radius="md" rows={2} />

        <Button onClick={handleSubmit} radius="xl" mt="xs"
          style={{ background: COLORS.navy, fontFamily: '"Outfit", sans-serif' }}>
          {pending ? 'Guardar Cambios' : 'Registrar Pendiente'}
        </Button>
      </div>
    </Modal>
  );
}